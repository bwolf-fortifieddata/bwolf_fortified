/**********************************************************************
File: IndexOptimize Add Check for Failure Step.sql
Author: Keith Buck
Created: 11/6/2018

Purpose: This script is used to add a second step to the index maintenance
SQL Agent job to check for failures. On newer versions of SQL (2014+) we
have the WAIT_AT_LOW_PRIORITY option for online index rebuilds
https://docs.microsoft.com/en-us/sql/t-sql/statements/alter-index-transact-sql?view=sql-server-2017

If this option causes the command to fail and move on to the next one we
usually don't want to return a job failure as it worked as intended. To
avoid the failure run this code to add a second step that reviews all
Index and Statistics updates that were done by step 1 to see if there
were real errors and accordingly returns failure or success.

This script assumes the job only has one step and all works is
logged. If the commands are not logged then this will not work.
**********************************************************************/

use msdb
go

IF EXISTS(SELECT * from msdb.dbo.sysjobs j INNER JOIN msdb.dbo.sysjobsteps s on j.job_id = s.job_id WHERE j.name LIKE 'IndexOptimize%' AND s.step_id != 1 and s.step_name = N'Check for Failure') 
BEGIN
	RETURN;
	RAISERROR('Job step exists',15,1) WITH NOWAIT;

END
--check to see if the command exists
DECLARE @ReturnCode			INT = 0
DECLARE @jobId				BINARY(16)
DECLARE @maxStep			INT
DECLARE @LastStep			INT
DECLARE @outputfile			NVARCHAR(200)


SELECT TOP 1 @jobId = job_id FROM msdb.dbo.sysjobs WHERE (name LIKE N'IndexOptimize%')
SELECT TOP 1 @maxStep = MAX(step_id) FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId
SET @LastStep =  @maxStep + 1
SELECT @outputfile = output_file_name FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId AND step_id = 1


--SELECT @jobId [jobid], @maxStep [MaxStep], @LastStep [LastStep], @outputfile [OutPutFile]
IF @jobId IS NULL OR @maxStep IS NULL OR @outputfile IS NULL
BEGIN
	RETURN;
	RAISERROR('Null value, please fix before continuing.',15,1) WITH NOWAIT;
END



---ADD THE SECOND STEP
EXEC  msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check for Failure', 
		@step_id=@LastStep, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET NOCOUNT ON
IF NOT EXISTS(SELECT * from msdb.dbo.sysjobs j INNER JOIN msdb.dbo.sysjobsteps s on j.job_id = s.job_id WHERE j.job_id = CONVERT(uniqueidentifier, $(ESCAPE_NONE(JOBID))) AND s.step_id = 1 AND s.command like ''%@WaitAtLowPriorityMaxDuration%'') 
BEGIN
	PRINT ''@WaitAtLowPriorityMaxDuration IS NOT SET FOR THIS JOB, SKIPPING CHECK AND RETURNING FAILURE''
	RETURN
END

DECLARE @jobid							UNIQUEIDENTIFIER
DECLARE @rundate						INT
DECLARE @runtime						INT
DECLARE @startdt						DATETIME
DECLARE @msg							VARCHAR(2048)
DECLARE @WaitAtLowPriorityMaxDuration	INT = 10

DECLARE @id				INT
DECLARE @command		NVARCHAR(MAX)
DECLARE @errmsg			NVARCHAR(MAX)
DECLARE @commandtype	NVARCHAR(60)
DECLARE @start			DATETIME
DECLARE @end			DATETIME
DECLARE @haserror		BIT = 0

--GET THE JOB ID
SELECT @jobid =  CONVERT(uniqueidentifier,$(ESCAPE_NONE(JOBID)))
SET @msg = ''Job Id is: '' + ISNULL(CAST(@jobid as varchar(50)), ''nuLL'')
RAISERROR(@msg,10,1) WITH NOWAIT;

--try to read the value of @WaitAtLowPriorityMaxDuration from the job step
DECLARE @tmp			VARCHAR(1000)
DECLARE @tmp2			VARCHAR(1000)
DECLARE @startLoc		INT
DECLARE @commaLoc		INT			
SELECT @tmp = s.command FROM msdb.dbo.sysjobsteps s WHERE s.job_id = @jobid AND  s.step_id = 1
SET @startLoc = CHARINDEX(''@WaitAtLowPriorityMaxDuration'',@tmp,1) + LEN(''@WaitAtLowPriorityMaxDuration'')
SET @commaLoc = CHARINDEX('','',@tmp,@startLoc)
SET @tmp2 = LTRIM(RTRIM(REPLACE(SUBSTRING(@tmp, @startLoc, @commaLoc-@startLoc),''='','''')))


IF ISNUMERIC(@tmp2) = 1
BEGIN
	SET @WaitAtLowPriorityMaxDuration = CAST(@tmp2 AS INT)
	PRINT ''@WaitAtLowPriorityMaxDuration has been set to '' + @tmp2
END	
ELSE
	PRINT ''Unable to determine WaitAtLowPriorityMaxDuration value in command, running with the default value of'' + CAST(@WaitAtLowPriorityMaxDuration AS VARCHAR(20))

PRINT ''''

--GET THE LATEST RUNTIME INFORMATION FROM ACTIVITY
SELECT 
		@startdt = a.start_execution_date
	FROM
	msdb.dbo.sysjobactivity a
WHERE
	a.job_id = @jobid

IF @startdt IS NULL
BEGIN
	RAISERROR(''Unable to get job start date'', 15,1);
	RETURN;
END

DECLARE curJob CURSOR FAST_FORWARD FOR 
SELECT 
	ID
	,Command
	,ErrorMessage
	,CommandType
	,StartTime
	,EndTime
	FROM
	FDDBA.dbo.CommandLog 
WHERE
	StartTime >= @startdt
	AND CommandType IN (''ALTER_INDEX'',N''UPDATE_STATISTICS'')
	AND ErrorMessage IS NOT NULL
	
OPEN curJob
FETCH NEXT FROM curJob INTO  @id, @command, @errmsg, @commandtype, @start, @end
WHILE @@FETCH_STATUS = 0
BEGIN
	IF  (@errmsg LIKE N''%Lock request time out period exceeded%'' 
		AND @commandtype = N''ALTER_INDEX''
		AND DATEDIFF(MINUTE, @start, @end) = @WaitAtLowPriorityMaxDuration)
	BEGIN--pretty much do nothing
		SET @msg = ''Wait at low priority error found for CommandLog.ID = '' + CAST(@id AS VARCHAR(20)) +''.''
		RAISERROR(@msg, 10,1) WITH NOWAIT;
	END
	ELSE 
	BEGIN
		SET @haserror = 1
		PRINT  ''Command type: '' + @commandtype
		PRINT ''Error Message: '' + @errmsg
		PRINT  ''DateDiff is: '' + CAST(DATEDIFF(MINUTE, @start, @end) AS VARCHAR(30))
		PRINT  ''''
		BREAK
	END


	FETCH NEXT FROM curJob INTO  @id, @command, @errmsg, @commandtype, @start, @end
END
CLOSE curJob
DEALLOCATE curJob

IF @haserror = 1
BEGIN
	RAISERROR(''Error(s) occurred in Index Maintenance job, please reveiw'',15,1) WITH NOWAIT;
END
ELSE
	RAISERROR(''No errors found'', 10,1) WITH NOWAIT;
', 
		@database_name=N'FDDBA', 
		@output_file_name= @outputfile, 
		@flags=0


--UPDATE THE PREVIOUS LAST STEP
EXEC  msdb.dbo.sp_update_jobstep 
		@job_id=@jobId
		,@step_id = @maxStep
		,@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0
GO


--EXEC  msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IndexOptimize - ALL_DATABASES', 
--		@step_id=1, 
--		@cmdexec_success_code=0, 
--		@on_success_action=1, 
--		@on_success_step_id=0, 
--		@on_fail_action=3, 
--		@on_fail_step_id=0, 
--		@retry_attempts=0, 
--		@retry_interval=0, 
--		@os_run_priority=0, @subsystem=N'CmdExec', 
--		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d FDDBA -Q "EXECUTE [dbo].[IndexOptimize] @SortInTempDB = ''Y'', @WaitAtLowPriorityMaxDuration = 10, @WaitAtLowPriorityAbortAfterWait =''SELF'',  @UpdateStatistics = ''ALL'', @OnlyModifiedStatistics = ''Y'',@Databases = ''ALL_DATABASES'', @LogToTable = ''Y''" -b', 
--		@output_file_name=N'\\NYdd1\SQLBackups\UAT\SQLJobOutput\UATSQL09$INST01\IndexOptimize_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(STRTDT))_$(ESCAPE_SQUOTE(STRTTM)).txt', 
--		@flags=0