/*****************************************************************************************************************
	Fortified Data FDDBA job update and removal script

Run each section manually and read the header before you execute it, this ensure you know what is going on and 
you have created any replacement objects that are needed
*****************************************************************************************************************/
use msdb
go
---------------------------------------------------------------------------------
--rename the cycle error log
---------------------------------------------------------------------------------
DECLARE @jobid	UNIQUEIDENTIFIER
IF EXISTS (SELECT * FROM dbo.sysjobs j inner join dbo.sysjobsteps s on j.job_id = s.job_id and s.command like '%exec sp_cycle_errorlog%' AND j.name != N'DBA - Cycle Errorlog Nightly')
BEGIN
	SELECT TOP 1 @jobid = j.job_id FROM dbo.sysjobs j inner join dbo.sysjobsteps s on j.job_id = s.job_id and s.command like '%exec sp_cycle_errorlog%'
	IF @jobid IS NOT NULL
	BEGIN
		EXEC msdb.dbo.sp_update_job @job_id= @jobid, @category_name=N'Database Maintenance'
		EXEC msdb.dbo.sp_update_job @job_id= @jobid, @new_name=N'DBA - Cycle Errorlog Nightly'
		RAISERROR('Job to cycle error log has been renamed.',10,1) WITH NOWAIT;
	END
	ELSE
		RAISERROR('Unable to find a job to run sp_cycle_errorlog',10,1) WITH NOWAIT;
END
ELSE
	RAISERROR('Could not find a job to run sp_cycle_errorlog',10,1) WITH NOWAIT;
go

---------------------------------------------------------------------------------
--RESET ANY OLA JOBS BACK TO MAINTENANCE CATEGORY
---------------------------------------------------------------------------------
RAISERROR('',10,1) WITH NOWAIT;
RAISERROR('-----------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR('Checking for Ola jobs to change category back to maintenance',10,1) WITH NOWAIT;
IF NOT EXISTS (SELECT * FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
	EXEC msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
END
DECLARE @job	SYSNAME
DECLARE @sql	NVARCHAR(MAX)

DECLARE curJOBS CURSOR FAST_FORWARD LOCAL FOR
SELECT
	j.name
	,N' Exec msdb.dbo.sp_update_job @job_name = N''' + j.name + N''' , @category_name = N''Database Maintenance'''
 FROM 
	msdb.dbo.sysjobs j
	INNER JOIN msdb.dbo.syscategories c on j.category_id = c.category_id
WHERE
	j.description like '%ola%'
	AND c.name != N'Database Maintenance'
	
OPEN curJOBS
FETCH NEXT FROM curJOBS INTO @job, @sql 
WHILE @@FETCH_STATUS = 0
BEGIN
	Print @job
	PRINT @sql
	PRINT ''
	EXECUTE sp_executesql @sql 
	FETCH NEXT FROM curJOBS INTO @job, @sql 
END
CLOSE curJOBS
DEALLOCATE curJOBS
GO


/*********************************************************************************************	
	DROP ALL FD JOBS		
BEFORE YOU RUN THIS ENSURE YOU HAVE SET UP SCHEDULES FOR ANY BACKUP JOBS
*********************************************************************************************/
RAISERROR('',10,1) WITH NOWAIT;
RAISERROR('-----------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR('Deleting all ''FD -*'' jobs.',10,1) WITH NOWAIT;

DECLARE @job	SYSNAME
DECLARE @sql	NVARCHAR(MAX)
DECLARE curJOBS2 CURSOR FAST_FORWARD LOCAL FOR
SELECT
	j.name
	,N' Exec msdb.dbo.sp_delete_job @job_name = N''' + j.name + N''';'
 FROM 
	msdb.dbo.sysjobs j
	INNER JOIN msdb.dbo.syscategories c on j.category_id = c.category_id
WHERE
	j.name LIKE 'FD -%'
	OR c.name LIKE N'Fortified%'
	
OPEN curJOBS2
FETCH NEXT FROM curJOBS2 INTO @job, @sql 
WHILE @@FETCH_STATUS = 0
BEGIN
	Print @job
	PRINT @sql
	PRINT ''
	--EXECUTE sp_executesql @sql 
	FETCH NEXT FROM curJOBS2 INTO @job, @sql 
END
CLOSE curJOBS2
DEALLOCATE curJOBS2
GO


/*********************************************************************************************	
	DROP ALL The Sentry Jobs if they exist
*********************************************************************************************/

USE [msdb]
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'SQL Sentry 2.0 Alert Trap')
BEGIN
	RAISERROR('Deleting job "SQL Sentry 2.0 Alert Trap"',10,1) WITH NOWAIT;
	EXEC msdb.dbo.sp_delete_job @job_name = N'SQL Sentry 2.0 Alert Trap', @delete_unused_schedule=1
END 


IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'SQL Sentry 2.0 Queue Monitor')
BEGIN
	RAISERROR('Deleting job "SQL Sentry 2.0 Queue Monitor"',10,1) WITH NOWAIT;
	EXEC msdb.dbo.sp_delete_job @job_name = N'SQL Sentry 2.0 Queue Monitor', @delete_unused_schedule=1
end
GO






--UPDATE ALERTS AND OPERATOR


/***	Drop Alert for  [Blocking]    ******/
USE [msdb]
GO
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Blocking')
BEGIN
	EXEC msdb.dbo.sp_delete_alert @name=N'Blocking'
	RAISERROR('Deleted blocking alert.',10,1) WITH NOWAIT;
END 
GO



/************************************************************************
	Operators 
	Delete any that are named FDDBA or have a fortified email
	deleting an operator will remove it from the response of an alert
************************************************************************/
DECLARE @operator		SYSNAME
WHILE EXISTS (SELECT * FROM dbo.sysoperators where name = 'FDDBA' or email_address like '%@fortifieddata.com')
begin
	SET @operator = NULL 
	SELECT TOP 1 @operator = name FROM dbo.sysoperators where name = 'FDDBA' or email_address like '%@fortifieddata.com'

	IF @operator IS NOT NULL
	BEGIN
		EXEC msdb.dbo.sp_delete_operator @name= @operator
		RAISERROR('Deleted Operator',10,1) WITH NOWAIT;
		RAISERROR(@operator,10,1) WITH NOWAIT;
	END
end



/************************************************************************
	Ola Job delete 
	This script will delete any ola jobs. This shoudl be run only if we
	are not leaving OLA maintenance on the machine.
************************************************************************/
--use msdb
--GO

--DECLARE @job	SYSNAME
--DECLARE @sql	NVARCHAR(MAX)
--RAISERROR('',10,1) WITH NOWAIT;
--RAISERROR('Deleting ALL Ola jobs.',10,1) WITH NOWAIT;
--RAISERROR('',10,1) WITH NOWAIT;
--DECLARE curJOBS3 CURSOR FAST_FORWARD LOCAL FOR
--SELECT
--	j.name
--	,N' Exec msdb.dbo.sp_delete_job @job_name = N''' + j.name + N''';'
-- FROM 
--	msdb.dbo.sysjobs j
--WHERE
--	j.description like '%ola%'
	
--OPEN curJOBS3
--FETCH NEXT FROM curJOBS3 INTO @job, @sql 
--WHILE @@FETCH_STATUS = 0
--BEGIN
--	Print @job
--	PRINT @sql
--	PRINT ''
--	EXECUTE sp_executesql @sql 
--	FETCH NEXT FROM curJOBS3 INTO @job, @sql 
--END
--CLOSE curJOBS3
--DEALLOCATE curJOBS3
--GO



/*****************************************************************************************************************
	FINALLY - DROP THE FDDBA DATABASE 
	YOU NEED TO MANUALLY CHECK IF ANY DATABASE BACKUPS EXIST AND DELETE THOSE TOO

*****************************************************************************************************************/
/*
--first list out any backups over the last 2 weeks
use msdb
set transaction isolation level read uncommitted

Select DISTINCT 
	S.database_name,
	Case When S.Type = 'D' Then 'Database'
		 When S.Type = 'I' Then 'Differential database'
		 When S.Type = 'L' Then 'Log'
		 When S.Type = 'F' Then 'File or filegroup'
		 When S.Type = 'G' Then 'Differential file'
		 When S.Type = 'P' Then 'Partial'
		 When S.Type = 'Q' Then 'Differential partial'
		 When S.Type is null Then 'null'
		 Else 'unknown' End BU_TYPE_DESC,
	CASE a.device_type
		WHEN NULL THEN 'NULL'
		WHEN 2 THEN 'Disk'
		WHEN 5 THEN 'Tape'
		WHEN 7 THEN 'Virtual Device'
		WHEN 105 THEN 'A permanent backup device'
	ELSE '' END AS [Backup Device Type]	,
	DATENAME(WEEKDAY,S.BACKUP_START_DATE) AS StartDay,
	S.BACKUP_START_DATE,
	Case When CHARINDEX('\', A.PHYSICAL_DEVICE_NAME,1) = 0 Then A.physical_device_name 
	Else REVERSE(SUBSTRING(REVERSE(A.PHYSICAL_DEVICE_NAME),1,CHARINDEX('\', REVERSE(A.PHYSICAL_DEVICE_NAME))-1)) 
	End AS FILENAME,
	CONVERT(DECIMAL(20,0),  cast(s.backup_size  as decimal)/1024/1024) as BackupSize_MB,
	CONVERT(DECIMAL(20,2),  cast(s.compressed_backup_size   as decimal)/1024/1024) as Compressed_MB ,
	CONVERT(DECIMAL(20,2),  cast(s.compressed_backup_size   as decimal)/1024/1024/1024) as Compressed_GB ,
	DATEDIFF(SECOND,S.BACKUP_START_DATE,S.backup_finish_date) as Run_time_sec
	, RIGHT('0' + CAST( DATEDIFF(SECOND,S.BACKUP_START_DATE,S.backup_finish_date) / 3600 AS VARCHAR),2) + ':' +
			RIGHT('0' + CAST(( DATEDIFF(SECOND,S.BACKUP_START_DATE,S.backup_finish_date) / 60) % 60 AS VARCHAR),2) + ':' +
			RIGHT('0' + CAST(DATEDIFF(SECOND,S.BACKUP_START_DATE,S.backup_finish_date) % 60 AS VARCHAR),2) AS RunTime
			
	,s.recovery_model
	,s.is_copy_only 
	,s.description 
	,s.is_snapshot
	,s.is_damaged 
	,s.is_password_protected
	,s.is_readonly
	,s.is_force_offline
	,A.PHYSICAL_DEVICE_NAME
	,S.backup_finish_date
    ,s.user_name
FROM	
	MSDB..backupset s
    	INNER JOIN MSDB..BACKUPMEDIAFAMILY A on S.MEDIA_SET_ID = A.MEDIA_SET_ID 
	LEFT JOIN msdb..restorehistory rs ON s.backup_set_id = rs.backup_set_id and rs.destination_database_name = s.database_name
Where
	1=1
	AND rs.destination_database_name IS NULL
	AND s.type IN ( 'D','I','L')
	AND S.database_name = 'FDDBA'
	and S.BACKUP_START_DATE >= DATEADD(day,-14,getdate())
ORDER BY 
	S.database_name,
	S.BACKUP_START_DATE DESC


--NOW RUN THE DROP
USE FDDBA
GO

ALTER DATABASE FDDBA SET SINGLE_USER WITH ROLLBACK IMMEDIATE
ALTER DATABASE FDDBA SET MULTI_USER 
GO
USE master
GO
DROP DATABASE FDDBA
GO
*/