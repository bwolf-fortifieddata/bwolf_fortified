USE MSDB
GO
set nocount on
  
DECLARE @NotificationOperator			SYSNAME	-- Name of the operator to notify in case of job failure, if NULL no notifcation is set up
DECLARE @jobname						SYSNAME
DECLARE @msg							VARCHAR(2048)
DECLARE @sql							NVARCHAR(500)

SET @NotificationOperator			= N'FDDBA'


--Get a list of jobs that we will work on based on the description
IF OBJECT_ID('tempdb..#joblist') IS NOT NULL
	DROP TABLE #joblist 
CREATE TABLE #joblist (jobname   SYSNAME, jobid UNIQUEIDENTIFIER)
INSERT INTO #joblist(jobid, jobname)
SELECT	
	j.job_id
	,j.name
 FROM
	msdb.dbo.sysjobs j 
	INNER JOIN msdb.dbo.syscategories c on j.category_id = c.category_id
 WHERE
	1=1
	AND ISNULL(notify_email_operator_id,0) < 1
	AND c.name like '%Fortified%'
/************************************************************************************
		Set up job failure notifications
************************************************************************************/
RAISERROR('',10,1) WITH NOWAIT;
IF @NotificationOperator IS NOT NULL
BEGIN
	DECLARE curJobs	CURSOR  FAST_FORWARD LOCAL FOR
	SELECT jobname FROM #joblist 
	OPEN curJobs
	FETCH NEXT FROM curJobs INTO @jobname
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @jobname AND notify_email_operator_id > 0)
		BEGIN
			SET @sql = N'EXEC msdb.dbo.sp_update_job @job_name=N'''  + @jobname  +''', 
			@notify_level_email=2, 
			@notify_level_netsend=2, 
			@notify_level_page=2, 
			@notify_email_operator_name=N''' +  @NotificationOperator   + ''''
			SET @msg = 'Adding operator ' + @NotificationOperator + ' to email notification for failure of job ''' + @jobname + '''.'
			RAISERROR(@msg,10,1) WITH NOWAIT;
			execute sp_executesql @stmt = @sql 
		END
		FETCH NEXT FROM curJobs INTO  @jobname
	END
	CLOSE curJobs
	DEALLOCATE curJobs
END
ELSE
	RAISERROR('Parameter @NotificationOperator is NULL so script cannot add email notification on job failure.',10,1) WITH NOWAIT;

