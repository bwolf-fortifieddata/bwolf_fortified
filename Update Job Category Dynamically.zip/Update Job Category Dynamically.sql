/******************************************************************************************************
Run this job to update the job category for database maintenance jobs that are not
already set to be Fortified Data jobs. It will also create the category if it cannot find it.
******************************************************************************************************/
USE MSDB
GO

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Fortified Data - Maintenance' AND category_class=1)
BEGIN
	EXEC msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Fortified Data - Maintenance'
END
DECLARE @job	SYSNAME
DECLARE @sql	NVARCHAR(MAX)

DECLARE curJOBS CURSOR FAST_FORWARD LOCAL FOR
SELECT
	j.name
	,N' Exec msdb.dbo.sp_update_job @job_name = N''' + j.name + N''' , @category_name = N''Fortified Data - Maintenance'''
 FROM 
	msdb.dbo.sysjobs j
	INNER JOIN msdb.dbo.syscategories c on j.category_id = c.category_id
WHERE
	1=1
	AND c.name not like '%Fortified%'
	AND (j.description like '%ola%'
		or 
		j.name = N'DBA - Cycle Errorlog Nightly')
	--AND j.name like 'DatabaseBackup %'
	--AND s.output_file_name IS NOT NULL
OPEN curJOBS
FETCH NEXT FROM curJOBS INTO @job, @sql 
WHILE @@FETCH_STATUS = 0
BEGIN
	Print @job
	PRINT @sql
	PRINT ''
	EXECUTE sp_executesql @sql 
	FETCH NEXT FROM curJOBS INTO @job, @sql 
END
CLOSE curJOBS
DEALLOCATE curJOBS
	
