Order of execution

1. Base config
    You should run the space report to check drive info, Perf- Quick Check to get an overview of the server and look at current tempdb size information to see what is already out there. These can help you determine what you need to 
2. FDDBA
3. Maintenance Solution if not already set up
4. Maintenance Post install config. You may need to create an alternate copy of this for your client specific needs.
5. Update Job Categories
6. Add alerts to all other FD maint jobs.


Additional Data Verification for FDDBA versions 1.1.0040 and later (would suggest version 1.1.0052 as minimum):

Due to client agnostic script changes it is possible that other errors/warnings could occur in FDDBA script. Even if do not see any messages output in the color red then please do the following steps and send output to Mike for analysis:

--if  single server -> run following queries in text results mode

select [name] as [sysmail_profile_name] from msdb.dbo.sysmail_profile
select [name], [domain], [value] from FDDBA.dbo.config_fddba2

--if multiserver and CMS is configured run following queries against server in text results mode (note this is returning the key values but it is easier to tell if problem with multiple result sets):

select [name] as [sysmail_profile_name] from msdb.dbo.sysmail_profile
select [value] as [config_profile_name] from FDDBA.dbo.config_fddba2 where [domain] = 'fddba\pStartUpCheck' and [name] = 'profile_name'
select [value] as [config_recipients] from FDDBA.dbo.config_fddba2 where [domain] = 'fddba\pStartUpCheck' and [name] = 'recipients'
select [value] as [config_traceflags] from FDDBA.dbo.config_fddba2 where [domain] = 'fddba\usp_EnableTraceFlags2' and [name] = 'trace_flags'
select [name] as [confg_xe_deadlocks] from sys.dm_xe_sessions where [name] = 'FD_deadlock_capture'

--if multiserver and any RED messages (errors or warnings) occur, save query message output and output of this query from that server:

select @@SERVERNAME as [server_name]
select [name], [domain], [value] from FDDBA.dbo.config_fddba2