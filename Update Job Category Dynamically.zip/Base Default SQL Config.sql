/*============================================================================
  File:     Base Default SQL Config

  Summary:  Fortified Data default configuration script
  
  Date:     Feb 2016

  Versions: 2005, 2008, 2012, 2014
------------------------------------------------------------------------------
  Written by Keith Buck, FORTIFIED DATA
	
  For more scripts and sample code, check out 
    http://www.FortifiedData.com

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
  CHANGES
  Date			Name	Notes
  10-23-2019	Keith	Added @mailDisplayName parameter for email	
============================================================================*/

print '/*'
USE [master]
print '*/'
GO
SET NOCOUNT ON

DECLARE @alerts									TABLE (Name SYSNAME, minsqlversion tinyint, severity int, message_id int)
DECLARE @config									TABLE (Name NVARCHAR(35), ValueToUse SQL_VARIANT)
DECLARE	@setMemoryDynamically					BIT	-- set to 1 to dynamically set, set to 0 and use @config table to insert memory data
DECLARE @setMAXDOPDynamically					BIT -- set to 1 to dynamically set max DOP, set to 0 and use @config table to insert MAXDOP value
DECLARE @createMailProfile						BIT -- will be defaulted to 0 (no)
DECLARE @mailAccountName						SYSNAME  -- will be defaulted to DBASQLSERVER
DECLARE @mailDisplayName						SYSNAME  -- Display name for email
DECLARE @mailEmailAddress						NVARCHAR(128)  -- From Email address for DB Mail
DECLARE @mailReplyAddress						NVARCHAR(128)	--Reply to Email address for DB Mail
DECLARE @mailSMTP								SYSNAME		--Mail server SMTP address or IP
DECLARE @mailPort								INT -- Will be defaulted to 25
DECLARE @mailUseSSL								BIT -- will be defaulted to 0 (No)
DECLARE @mailUserName							SYSNAME	-- user name to log onto mail server, leave NULL if the mail server does not require authentication
DECLARE @mailUserPassword						SYSNAME -- leave NULL unless @mailUserName is NOT NULL
DECLARE @sqlAgentdatbabaseMailProfile			SYSNAME	--Enter the name of the mail profile to use for SQL Agent. If not already set this will set it and use it for all the agent alerts
DECLARE @sqlAgentOperatorName					SYSNAME	--Name of the operator that exists or will be created. 
DECLARE @sqlAgentOperatorEmail					NVARCHAR(100) --Email address of the operator

DECLARE	@configureTempdb						BIT
DECLARE	@tempdbPath								NVARCHAR(256) --new tempdb file path , leave null to use curent path of first data file (based on file_id), if path provided all tempdb files will be moved
DECLARE @tempdbDataFileSizeMB					BIGINT -- tempdb data file size
DECLARE @tempdbDataFilegGrowthMB				BIGINT -- tempdb data file growth
DECLARE @tempdbLogFileSizeMB					BIGINT -- tempdb log file size
DECLARE @tempdbLogFilegGrowthMB					BIGINT -- tempdb log file growth
DECLARE	@tempdbNumFiles							TINYINT  --total number of tempdb data files, leave null or 0 to set dynamically (will match maxdop dynamic setting)
DECLARE @adjustUserDbGrowth						BIT

DECLARE @createdOperator						BIT
DECLARE @createAlert							BIT --Was alert created (to know if notifications should be run)
DECLARE @updateAlert							BIT --Was alert updated since disabled
DECLARE @script_version                         VARCHAR(25)
DECLARE @CreateErrorLogJob						BIT  -- create the cycle error log job. If creating FDDBA then the job will be added by it, so set this param to 0
DECLARE @runit									BIT

SET @script_version							= '2018-10-16 18:38:00 UTC-5' --set to date script modified
SET @createdOperator						= 0 --Was FDDBA operator created (to know if notifications should be run)

/****************************************************************************************************
	Configuration options section. Here is where we set some options about things like sp_configure
	settings and memory. Setting items in here will include or exclude them from running
****************************************************************************************************/

SET @runit									= 0 --1 = execute changes, 0 = print only (old way)
SET	@configureTempdb						= 1 --Should this script adjust tempdb data files, default is 1 (yes)
SET @adjustUserDbGrowth						= 1 -- set to 1 to enable scripting out of asjusting user databse file growths

SET @setMemoryDynamically					= 1					-- set to 1 to dynamically set, set to 0 and use @config table to insert memory value
SET @setMAXDOPDynamically					= 1					-- set to 1 to dynamically set max DOP, set to 0 and use @config table to insert MAXDOP value

SET @tempdbDataFileSizeMB					= 8192	-- tempdb data file size
SET @tempdbDataFilegGrowthMB				= 1024  -- tempdb data file growth
SET @tempdbLogFileSizeMB					= 15360  -- tempdb log file size
SET @tempdbLogFilegGrowthMB					= 1024  -- tempdb log file growth
SET @tempdbPath								= NULL  -- new tempdb file path, leave null to use curent path, if path provided all tempdb files will be moved
SET	@tempdbNumFiles							= 0    --total number of tempdb data files, leave null or 0 to set dynamically (will match maxdop dynamic setting)

SET @CreateErrorLogJob						= 1  -- create the cycle error log job. If creating FDDBA then the job will be added by it, so set this param to 0 

SET @createMailProfile						= 1 
SET @mailSMTP								= N'mailservername'				-- Enter a DNS name or IP address
SET @mailPort								= 25 				-- 25 is the defualt value, override if using a different port
SET @mailUseSSL								= 0					--0 is the default, do not use SSL
SET @mailAccountName						= N'DBASQLSERVER'	 -- DBASQLSERVER is the default value
SET @mailDisplayName						= 'CLIENT-NAME SQL DBA'  -- Display name for email
SET @mailEmailAddress						= N'dba@fortifieddata.com'  -- From Email address for DB Mail
SET @mailReplyAddress						= N'dba@fortifieddata.com'	-- Reply to address for DB Mail
SET @mailUserName							= NULL	-- user name to log onto mail server, leave NULL if the mail server does not require authentication
SET @mailUserPassword						= NULL  -- leave NULL unless @mailUserName is NOT NULL

SET @sqlAgentdatbabaseMailProfile			= N'Agent Mail'	--Enter the name of the mail profile to use for SQL Agent. This is the profile that will be created if @createMailProfile is set to 1 
SET @sqlAgentOperatorName					= N'FDDBA'			--Name of the operator that exists or will be created. 
SET @sqlAgentOperatorEmail					= N'dba@fortifieddata.com'--Email address of the operator


--Insert any config settins you want here, the first few are defaults we like to use, memory settings can be set here'
--or you can let it be dynamically configured using the @Memory parameter
INSERT INTO @config(Name, ValueToUse) VALUES ('remote admin connections', 1)
INSERT INTO @config(Name, ValueToUse) VALUES ('scan for startup procs', 1)
INSERT INTO @config(Name, ValueToUse) VALUES ('optimize for ad hoc workloads', 1)
INSERT INTO @config(Name, ValueToUse) VALUES ('Agent XPs', 1)
INSERT INTO @config(Name, ValueToUse) VALUES ('Database Mail XPs', 1)
INSERT INTO @config(Name, ValueToUse) VALUES ('backup compression default',1)
INSERT INTO @config(Name, ValueToUse) VALUES ('cost threshold for parallelism', 15)
--INSERT INTO @config(Name, ValueToUse) VALUES ('contained database authentication', 1)
--INSERT INTO @config(Name, ValueToUse) VALUES ( 'max server memory (MB)',2147483647) 
--INSERT INTO @config(Name, ValueToUse) VALUES ('min server memory (MB)',16)
--INSERT INTO @config(Name, ValueToUse) VALUES ('max degree of parallelism',0)

--TO ADD MORE ALERTS JUST INSERT ADDITIONAL ROWS BELOW
INSERT INTO @alerts VALUES (N'Error 823',9,NULL,823)
INSERT INTO @alerts VALUES (N'Error 824',9,NULL,824)
INSERT INTO @alerts VALUES (N'Error 825',9,NULL,825)
INSERT INTO @alerts VALUES (N'Severity 016',9,16,NULL)
INSERT INTO @alerts VALUES (N'Severity 017',9,17,NULL)
INSERT INTO @alerts VALUES (N'Severity 018',9,18,NULL)
INSERT INTO @alerts VALUES (N'Severity 019',9,19,NULL)
INSERT INTO @alerts VALUES (N'Severity 020',9,20,NULL)
INSERT INTO @alerts VALUES (N'Severity 021',9,21,NULL)
INSERT INTO @alerts VALUES (N'Severity 022',9,22,NULL)
INSERT INTO @alerts VALUES (N'Severity 023',9,23,NULL)
INSERT INTO @alerts VALUES (N'Severity 024',9,24,NULL)
INSERT INTO @alerts VALUES (N'Severity 025',9,25,NULL)
INSERT INTO @alerts VALUES (N'AG Role Change 1480',11, NULL, 1480)



--------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

DECLARE @nsql									NVARCHAR(2048) 
DECLARE @sql									VARCHAR(2048) 
DECLARE @currentSizeMb							INT
DECLARE @currentGrowth							INT
DECLARE @IsPercentGrowth						BIT
DECLARE @DBName									SYSNAME
DECLARE @FileName								NVARCHAR(256)
DECLARE @page_verify_option						BIT
DECLARE @is_auto_shrink_on						BIT
DECLARE @is_auto_close_on						BIT

DECLARE @instanceCount							INT
DECLARE @numanodes								INT
DECLARE @schedulers								INT
DECLARE @tempdCurrentDataFileCount				INT
DECLARE @tempdLogFileCount						INT
DECLARE @typedesc								NVARCHAR(60)
DECLARE @logicalName							SYSNAME
DECLARE @physicalName							SYSNAME
DECLARE @msg									VARCHAR(500)



/****************************************************************************************************
									HEADER
****************************************************************************************************/
RAISERROR ('------------------------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('------------------------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
SELECT @msg = '--	Configuration Change script for SQL Server Instance [' + CAST(@@SERVERNAME AS VARCHAR(128)) + '] which is running build ' + 
	CONVERT(VARCHAR(3), CONVERT(TINYINT, SUBSTRING(CONVERT(BINARY(4), @@MICROSOFTVERSION), 1, 1))) + '.' + 
	CONVERT(VARCHAR(3), CONVERT(TINYINT, SUBSTRING(CONVERT(BINARY(4), @@MICROSOFTVERSION),2,1))) + '.' + 
	CONVERT(VARCHAR(6), CONVERT(SMALLINT, SUBSTRING(CONVERT(BINARY(4), @@MICROSOFTVERSION),3,2))) + ' ' + 
	CONVERT(VARCHAR(50), SERVERPROPERTY('Edition'))
RAISERROR (@msg,10,1) WITH NOWAIT;
SELECT @msg = '--	Created on ' + CONVERT(VARCHAR(30),GETDATE() ,121) + ' by Fortified Data© www.fortifieddata.com with script version ' + @script_version
RAISERROR (@msg,10,1) WITH NOWAIT;
RAISERROR ('------------------------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('------------------------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;

/****************************************************************************************************
							TEMPDB Configuration
****************************************************************************************************/
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('/***									tempdb Configuration									***/',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;


IF @configureTempdb = 0 
BEGIN
	RAISERROR (N'--Not going to make any changes to tempdb.',10,1) with nowait;
END
ELSE
BEGIN

	IF ISNULL(@tempdbNumFiles,0) = 0
	BEGIN
		DECLARE @Instances TABLE
		( Value NVARCHAR(100),
		 InstanceNames NVARCHAR(100),
		 Data NVARCHAR(100))

		INSERT INTO @Instances
		EXECUTE xp_regread
		  @rootkey = 'HKEY_LOCAL_MACHINE',
		  @key = 'SOFTWARE\Microsoft\Microsoft SQL Server',
		  @value_name = 'InstalledInstances'

		SELECT 
			@instanceCount = count(*) 
		 FROM
			@Instances 

		IF @instanceCount < 1 
			SET @instanceCount = 1


		SELECT @numanodes = count(*) FROM (SELECT DISTINCT memory_node_id FROM sys.dm_os_memory_clerks Where memory_node_id != 64) as x;
		SELECT @schedulers=  scheduler_count FROM	sys.dm_os_sys_info


		IF @instanceCount = 1
		BEGIN
			IF @schedulers > 8
				SET @tempdbNumFiles = 8
			ELSE  
				SET @tempdbNumFiles = @schedulers 
		END
		ELSE
		BEGIN
			IF @schedulers > 8 
			BEGIN
				SET @tempdbNumFiles = CAST(@schedulers/@numanodes AS INT)
				IF @tempdbNumFiles >8 
					SET @tempdbNumFiles = 8
			END
			ELSE  
				SET @tempdbNumFiles = @schedulers 
		END
	END

	RAISERROR (N'--Moving TempDb log, adding data files, setting size and growth',10,1) with nowait;
	--Get and set the path for tempdb
	IF @tempdbPath IS NULL
	BEGIN
		SELECT  
			TOP 1 @tempdbPath =   SUBSTRING(physical_name,1, LEN(physical_name) - CHARINDEX('\', REVERSE(physical_name)) + 1)
		  FROM
			sys.master_files 
		WHERE 
			database_id = db_id(N'tempdb') 
			AND type_desc =N'ROWS'
		 ORDER BY 
			file_id
	END
	ELSE
	BEGIN
		IF SUBSTRING(@tempdbPath,LEN(@tempdbPath),1) != N'\'
			SET @tempdbPath = @tempdbPath + N'\'
	END
	
	SET @tempdCurrentDataFileCount = 0
	SET @tempdLogFileCount = 0
	--cursor through each existing file
	DECLARE curTempDB CURSOR FAST_FORWARD LOCAL FOR 
	select  type_desc, name,
					RIGHT(physical_name, CHARINDEX('\', REVERSE('.' + physical_name)) - 1) AS [File Name]
				from sys.master_files where database_id = db_id(N'tempdb') --AND type_desc =N'ROWS'

	OPEN curTempDB
	FETCH NEXT FROM curTempDB INTO @typedesc, @logicalName, @physicalName
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		IF @typedesc = 'ROWS'
		BEGIN
			SET @sql = 'ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N''' + @logicalName +''', FILENAME = N''' + @tempdbPath + @physicalName + ''', SIZE =' + CAST(@tempdbDataFileSizeMB *1024 AS VARCHAR(30)) + 'kb, FILEGROWTH = ' +  CAST(@tempdbDataFilegGrowthMB *1024 AS VARCHAR(30)) + 'kb, MAXSIZE = UNLIMITED)
			;'
			SET @tempdCurrentDataFileCount = @tempdCurrentDataFileCount + 1
		END
		ELSE
		BEGIN
			SET @sql = 'ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N''' + @logicalName +''', FILENAME = N''' + @tempdbPath + @physicalName + ''', SIZE =' + CAST(@tempdbLogFileSizeMB *1024 AS VARCHAR(30)) + 'kb, FILEGROWTH = ' +  CAST(@tempdbLogFilegGrowthMB *1024 AS VARCHAR(30)) + 'kb, MAXSIZE = UNLIMITED)
			;'
			SET @tempdLogFileCount = @tempdLogFileCount + 1
		END
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		FETCH NEXT FROM curTempDB INTO @typedesc, @logicalName, @physicalName
	END
	CLOSE curTempDB
	DEALLOCATE curTempDB

	--Sanity check, we don't know how many files are already in tempdb and there may be the same or more than we recommended, if so warn about it
	If @tempdCurrentDataFileCount >= @tempdbNumFiles
	BEGIN
		SET @msg = '--WARNING-WARNING-WARNING: You asked for, or the script suggested, ' + CAST(@tempdbNumFiles AS VARCHAR(20)) +' tempdb data files however the instance already has ' + CAST(@tempdCurrentDataFileCount AS VARCHAR(20)) +
			' data files.'
		RAISERROR (@msg,10,1) WITH NOWAIT;
	END
	--now lets set up new files if needed
	WHILE @tempdCurrentDataFileCount < @tempdbNumFiles
	BEGIN
		Set @sql = N'ALTER DATABASE [tempdb] ADD FILE (Name=N''tempdb_0' + CAST(@tempdCurrentDataFileCount -1 AS VARCHAR(5)) + ''', FILENAME = N''' + @tempdbPath + 'tempdb_0' + 
				CAST(@tempdCurrentDataFileCount -1 AS VARCHAR(5)) + '.ndf'' , SIZE =' + CAST(@tempdbDataFileSizeMB *1024 AS VARCHAR(30)) + 'kb, FILEGROWTH = ' +  CAST(@tempdbDataFilegGrowthMB *1024 AS VARCHAR(30)) + 'kb, MAXSIZE = UNLIMITED)
				;'
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		SET @tempdCurrentDataFileCount =  @tempdCurrentDataFileCount + 1
	END
END
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;



/****************************************************************************************************
							MSDB Configuration
****************************************************************************************************/
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('/***									MSDB Configuration										   ***/',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;


--	Data File
SELECT 
	@currentSizeMb = f.size/128 
	,@IsPercentGrowth = f.is_percent_growth
	,@currentGrowth =  f.growth 
 FROM 
	sys.master_files f inner join sys.databases d on f.database_id = d.database_id 
 WHERE 
	d.name = N'msdb' 
	And type_desc =N'ROWS' 
	And f.name = N'MSDBData'

IF @currentSizeMb < 512 
BEGIN
	RAISERROR ('--Setting  data file size to 512 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [msdb] MODIFY FILE ( NAME = N''MSDBData'', SIZE = 524288KB);
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END

IF @IsPercentGrowth = 1 or (@IsPercentGrowth = 0 and @currentGrowth < 512)
BEGIN
	RAISERROR ('--Setting  data file growth rate  to 512 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [msdb] MODIFY FILE ( NAME = N''MSDBData'', FILEGROWTH = 524288KB );
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END

--Log File
SELECT 
	@currentSizeMb = f.size/128 
	,@IsPercentGrowth = f.is_percent_growth, 
	@currentGrowth =  f.growth 
 FROM 
	sys.master_files f inner join sys.databases d on f.database_id = d.database_id 
 WHERE 
	d.name = N'msdb' 
	And type_desc =N'LOG' 
	And f.name = N'MSDBLog'

IF @currentSizeMb < 100 
BEGIN
	RAISERROR ('--Setting log file size to 100 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [msdb] MODIFY FILE ( NAME = N''MSDBLog'', SIZE = 102400KB);
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
IF @IsPercentGrowth = 1 or (@IsPercentGrowth = 0 and @currentGrowth < 512)
BEGIN
	RAISERROR ('--Setting  log file growth rate  to 512MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [msdb] MODIFY FILE ( NAME = N''MSDBLog'', FILEGROWTH = 524288KB );
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;



/****************************************************************************************************
							MASTER File Configuration
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('/***									master Configuration										   ***/',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
--	Data File
SELECT 
	@currentSizeMb = f.size/128 
	,@IsPercentGrowth = f.is_percent_growth
	,@currentGrowth =  f.growth 
 FROM 
	sys.master_files f inner join sys.databases d on f.database_id = d.database_id 
 WHERE 
	d.name = N'master' 
	And type_desc =N'ROWS' 
	And f.name = N'master'

IF @currentSizeMb < 256 
BEGIN
	RAISERROR ('--Setting data file size to 256 MB',10,1) WITH NOWAIT;	
	SET @sql = '	ALTER DATABASE [master] MODIFY FILE ( NAME = N''master'', SIZE = 262144KB);
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END

IF @IsPercentGrowth = 1 or (@IsPercentGrowth = 0 and @currentGrowth < 512)
BEGIN
	RAISERROR ('--Setting data file growth rate to 512 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [master] MODIFY FILE ( NAME = N''master'', FILEGROWTH = 524288KB );
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END


--Log File
SELECT 
	@currentSizeMb = f.size/128 
	,@IsPercentGrowth = f.is_percent_growth
	,@currentGrowth =  f.growth 
 FROM 
	sys.master_files f inner join sys.databases d on f.database_id = d.database_id 
WHERE 
	d.name = N'master' 
	And type_desc =N'LOG' 
	And f.name = N'mastlog'

IF @currentSizeMb < 64 
BEGIN
	RAISERROR ('--Setting log file size to 64 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [master] MODIFY FILE ( NAME = N''mastlog'', SIZE = 65536KB);
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
IF @IsPercentGrowth = 1 or (@IsPercentGrowth = 0 and @currentGrowth < 512)
BEGIN
	RAISERROR ('--Setting  log file growth rate  to 512MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [master] MODIFY FILE ( NAME = N''mastlog'', FILEGROWTH = 524288KB );
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;






/****************************************************************************************************
							MODEL File Configuration
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('/***									MODEL Configuration										   ***/',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
--	Data File
SELECT 
	@currentSizeMb = f.size/128 
	,@IsPercentGrowth = f.is_percent_growth
	,@currentGrowth =  f.growth 
 FROM 
	sys.master_files f inner join sys.databases d on f.database_id = d.database_id 
WHERE 
	d.name = N'model' 
	And type_desc =N'ROWS'
	 And f.name = N'modeldev'

IF @currentSizeMb < 512 
BEGIN
	RAISERROR ('--Setting data file size to 512 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [model] MODIFY FILE ( NAME = N''modeldev'', SIZE = 131072KB);
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
IF @IsPercentGrowth = 1 or (@IsPercentGrowth = 0 and @currentGrowth < 512)
BEGIN
	RAISERROR ('--Setting  data file growth rate  to 512 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [model] MODIFY FILE ( NAME = N''modeldev'', FILEGROWTH = 524288KB );
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END

--Log FIle
SELECT 
	@currentSizeMb = f.size/128 
	,@IsPercentGrowth = f.is_percent_growth
	,@currentGrowth =  f.growth 
 FROM 
	sys.master_files f inner join sys.databases d on f.database_id = d.database_id 
WHERE 
	d.name = N'model'
	And type_desc =N'LOG' 
	And f.name = N'modellog'

IF @currentSizeMb < 128 
BEGIN
	RAISERROR ('--Setting Log file size to 128 MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [model] MODIFY FILE ( NAME = N''modellog'', SIZE = 131072KB);
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
IF @IsPercentGrowth = 1 or (@IsPercentGrowth = 0 and @currentGrowth < 512)
BEGIN
	RAISERROR ('--Setting log file growth rate  to 512MB',10,1) WITH NOWAIT;
	SET @sql = '	ALTER DATABASE [model] MODIFY FILE ( NAME = N''modellog'', FILEGROWTH = 524288KB );
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;



/****************************************************************************************************
							System Configuration 
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('/***								System Configuration										   ***/',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;


RAISERROR ('--Setting "show advanced options" to 1',10,1) WITH NOWAIT;
SET @sql = '	EXEC SP_CONFIGURE ''show advanced options'', 1
	;
	RECONFIGURE WITH OVERRIDE;
	;'
RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)




DECLARE @name		NVARCHAR(35)
DECLARE @value		SQL_VARIANT

DECLARE curConfig CURSOR FAST_FORWARD LOCAL FOR
SELECT Name, ValueToUse FROM @config
OPEN curConfig
FETCH NEXT FROM curConfig INTO @name, @value
WHILE @@FETCH_STATUS = 0
BEGIN
	IF Exists (SELECT 1 FROM sys.configurations WHERE name = @name)
	Begin
		IF Not Exists(SELECT 1 FROM sys.configurations WHERE name = @name and value_in_use = @value)
		BEGIN
			set @msg = '--Setting "' + @name + '" to ' + cast(@value as varchar(60)) 
			RAISERROR (' ',10,1) WITH NOWAIT;
			RAISERROR (@msg,10,1) WITH NOWAIT;
			SELECT @msg = '-- Current value for ' + @name + ' is: ' + cast(value_in_use AS VARCHAR(1000)) from sys.configurations WHERE name = @name
			RAISERROR (@msg,10,1) WITH NOWAIT;
			SET @sql = '	EXEC SP_CONFIGURE ''' + @name +''', ' + CAST( @value AS VARCHAR(500)) + '
	;
	RECONFIGURE WITH OVERRIDE;
	;'
			RAISERROR (@sql,10,1) WITH NOWAIT;
			IF (@runit=1) EXECUTE(@sql)
		END 
		ELSE
		BEGIN
			set @msg = '--Setting "' + @name + '" already has its value set to ' + cast(@value as varchar(60))  + ' so value will not be updated.'
			RAISERROR (@msg,10,1) WITH NOWAIT;
		END
	End
	ELSE
	Begin
		set @msg = '--SETTING"' + @name + '" DOES NOT EXIST AND THEREFORE CANNOT BE CHANGED.'
		RAISERROR (@msg,10,1) WITH NOWAIT;
	End
	FETCH NEXT FROM curConfig INTO @name, @value
END
CLOSE curConfig
DEALLOCATE curConfig




/***	Memory Configuration	***/
--MAX MEMORY SETTING
--which is to reserve 1 GB of RAM for the OS, 
--1 GB for each 4 GB of RAM installed from 4 to 16 GB, 
--and then 1 GB for every 8 GB RAM installed above 16 GB RAM.
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('	------------ Max Memory Cofiguration ---------------',10,1) WITH NOWAIT;

DECLARE @freemem		int
DECLARE @totalmem		int
DECLARE @i				int
DECLARE @maxmem			int
DECLARE @minmem			int
DECLARE @numinstances	int
DECLARE @maxdop			SQL_VARIANT
DECLARE @curMaxMem		int

SET @freemem			= 1

DECLARE @GetInstances TABLE
( Value NVARCHAR(100),
 InstanceNames NVARCHAR(100),
 Data NVARCHAR(100))

INSERT INTO @GetInstances
EXECUTE xp_regread
  @rootkey = 'HKEY_LOCAL_MACHINE',
  @key = 'SOFTWARE\Microsoft\Microsoft SQL Server',
  @value_name = 'InstalledInstances'

SELECT 
	@numinstances = count(*) 
 FROM
	@GetInstances 

IF @numinstances < 1 
	SET @numinstances = 1

IF @@MICROSOFTVERSION >= 167773760 --10.0.1600
BEGIN
  SET @nsql = N'SELECT @totalmem = ROUND(Cast(total_physical_memory_kb as float) /1024/1024,0) FROM sys.dm_os_sys_memory;'
END
ELSE
BEGIN
	SET @nsql = N'select @totalmem = ROUND(Cast(physical_memory_in_bytes as float) /1024/1024/1024,0) from sys.dm_os_sys_info;'
END
EXECUTE sp_executesql @nsql, N'@totalmem int OUTPUT', @totalmem=@totalmem OUTPUT

SELECT 
	@curMaxMem = 	CAST(value_in_use AS INT)
 FROM
	sys.configurations
WHERE
	name = N'max server memory (MB)'

If @curMaxMem IS NULL
	SET	@curMaxMem = 0

IF @totalmem > 4
BEGIN
	IF @totalmem <= 16
		SET @freemem = @freemem + (@totalmem - 4)/4
	ELSE
		SET @freemem = @freemem + 3 + ((@totalmem-16)/8)
END

SET @maxmem = ((@totalmem - @freemem)*1024 )/@numinstances
SET @minmem = ((@totalmem /2) * 1024)/@numinstances

SET @msg = '--	Total Memory:	' + CAST(@totalmem AS VARCHAR(30)) + '
--	Required Free Memory:	' + CAST (@freemem  AS VARCHAR(30)) + '
--	Max Memory GB:	' + CAST (@totalmem - @freemem AS VARCHAR(30)) +' 
--	Current Max Memory Setting:	' + CAST (@curMaxMem AS VARCHAR(30)) +' 
--	Recommended Max Memory Setting MB:	' + CAST (@maxmem AS VARCHAR(30)) +' 
--	Number of SQL instances found:	' + CAST (@numinstances AS VARCHAR(30)) 
	
RAISERROR (@msg,10,1) WITH NOWAIT;
IF @setMemoryDynamically = 1 AND @maxmem != @curMaxMem
BEGIN
	SET @sql = '	EXEC SP_CONFIGURE ''max server memory (MB)'', ' + CAST( @maxmem AS VARCHAR(50)) +  '
	;
	RECONFIGURE WITH OVERRIDE;
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
ELSE
	RAISERROR ('-- Current memory and recommended memory are the same value therefore no change is required.',10,1) WITH NOWAIT;


SELECT @numanodes = count(*) FROM (SELECT DISTINCT memory_node_id FROM sys.dm_os_memory_clerks Where memory_node_id != 64) as x;
SELECT @schedulers=  scheduler_count FROM	sys.dm_os_sys_info

------------TODO
------------TEST WITH VARIOUS VALUES FOR NUMA NODES AND SCHEDULERS


RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('	------------ Max Degree Of Parallelism Cofiguration ---------------',10,1) WITH NOWAIT;
IF @numinstances = 1
BEGIN
	IF @schedulers > 8
		SET @maxdop = 8
	ELSE
		SET @maxdop = 0
END
ELSE
BEGIN
	IF @schedulers > 8 
	BEGIN
		SET @maxdop = CAST(@schedulers/@numanodes AS INT)
		IF @maxdop >8 
			SET @maxdop = 8
	END
END

DECLARE @curDOP		INT
SELECT 
	@curDOP = 	CAST(value_in_use AS INT)
 FROM
	sys.configurations
WHERE
	name = N'max degree of parallelism'


SET @msg = '--	Instances Found:' + CAST(@numinstances AS VARCHAR(30)) + '
--	Schedulers:	' + CAST (@schedulers  AS VARCHAR(30)) + '
--	Numa Nodes:	' + CAST (@numanodes AS VARCHAR(30)) + ' 
--  Current Max Degree of Parallelism: ' + CAST(@curDOP AS VARCHAR(30)) 
RAISERROR (@msg,10,1) WITH NOWAIT;

IF @setMAXDOPDynamically = 1
BEGIN
	If @curDOP = CAST(@maxdop AS INT)
	BEGIN
		set @msg = '--Setting "Max Degree of Parallelism" already has its value set to ' + cast(@curDOP as varchar(60))  + ' so value will not be updated.'
		RAISERROR (@msg,10,1) WITH NOWAIT;
	END
	ELSE
	BEGIN
		SET @sql = '	EXEC sp_configure  ''max degree of parallelism'', ' + cast(@maxdop as VARCHAR(50)) + ' 
		;
		RECONFIGURE WITH OVERRIDE
		;'
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
	END
END

RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;






/****************************************************************************************************
							Database Growth Options - setting per database
****************************************************************************************************/
If @adjustUserDbGrowth = 1
BEGIN
	RAISERROR ('',10,1) WITH NOWAIT;
	RAISERROR ('',10,1) WITH NOWAIT;
	RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
	RAISERROR ('/***				 DB Growth Options: Changing for all user databases if required				   ***/',10,1) WITH NOWAIT;
	RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
	RAISERROR ('',10,1) WITH NOWAIT;

	DECLARE FileName_cursor CURSOR FAST_FORWARD LOCAL
	FOR SELECT 
			d.name
			,f.name
		  FROM 
			sys.master_files f 
			INNER JOIN sys.databases d ON d.database_id = f.database_id 
		 WHERE 
			f.is_read_only = 0 
			AND f.state = 0
			AND f.database_id > 4
			--AND(SA.maxsize <> -1 OR SA.growth <> 64000) -- Exclude files that have autogrowth on or maxsize set to 500mb
			--AND SA.growth <> 64000 -- Exclude files that have autogrowth on or maxsize set to 500mb

	OPEN FileName_cursor
	FETCH NEXT FROM FileName_cursor INTO @DBName, @FileName
	WHILE @@FETCH_STATUS = 0
	BEGIN
	
		SET @msg = '--Processing Database:' + @DBName + ' File Name: "' + @FileName + '",'
		RAISERROR (@msg,10,1) WITH NOWAIT;
		SET @sql = 'ALTER DATABASE [' + @DBName + '] MODIFY FILE (NAME = ''' + @FileName + ''', FILEGROWTH = 524288KB)
		;' -- , MAXSIZE = UNLIMITED)'
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;

		FETCH NEXT FROM FileName_cursor INTO @DBName, @FileName
	END
	CLOSE FileName_cursor
	DEALLOCATE FileName_cursor
	RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
	RAISERROR ('',10,1) WITH NOWAIT;
END
ELSE
BEGIN
	RAISERROR ('',10,1) WITH NOWAIT;
	RAISERROR ('--User database growth options have been bypassed. To enable them set parameter @adjustUserDbGrowth to 1.',10,1) WITH NOWAIT;
	RAISERROR ('',10,1) WITH NOWAIT;
END


/****************************************************************************************************
							Database Settings (checksum, autoshrink and autoclose
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('/***			Database Options (PageVerify=checksum, auto_shrink off, auto_close off: 
					Changing for all user databases if required				   ***/',10,1) WITH NOWAIT;
RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;
--RAISERROR ('	------------ Database Options (PageVerify=checksum, auto_shrink off, auto_close off: Changing for all user databases if required ---------------',10,1) WITH NOWAIT;

DECLARE FileName_cursor CURSOR FAST_FORWARD LOCAL FOR 
	SELECT
		SD.[name]
		,page_verify_option
		,is_auto_shrink_on
		,is_auto_close_on
	 FROM 
		sys.databases SD
	WHERE 
		SD.database_id > 4
		and SD.is_read_only = 0 
		and SD.state_desc = N'ONLINE'
		AND SD.page_verify_option IN (0, 1)
		OR SD.is_auto_shrink_on = 1
		OR SD.is_auto_close_on = 1
		
OPEN FileName_cursor
FETCH NEXT FROM FileName_cursor INTO @DBName, @page_verify_option, @is_auto_shrink_on, @is_auto_close_on
WHILE @@FETCH_STATUS = 0
BEGIN
	IF @page_verify_option = 1
	BEGIN
		SET @msg =  '--Processing Database (Page Verify) [' + @DBName + '] ' 
		RAISERROR(@msg,10,1)WITH NOWAIT;
		SET @sql = 'ALTER DATABASE [' + @DBName + '] SET PAGE_VERIFY CHECKSUM  WITH NO_WAIT
		;'
		RAISERROR(@sql,10,1)WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;
	END
	
	IF @is_auto_shrink_on = 1
	BEGIN
		SET @msg =  '--Processing Database (Shrink) [' + @DBName + '] ' 	
		RAISERROR(@msg,10,1)WITH NOWAIT;
		SET @sql = 'ALTER DATABASE [' + @DBName + '] SET AUTO_SHRINK OFF  WITH NO_WAIT
		;'	
		RAISERROR(@sql,10,1)WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;
	END
	
	IF @is_auto_close_on = 1
	BEGIN
		SET @msg =  '--Processing Database (Close) [' + @DBName + '] '
		RAISERROR(@msg,10,1)WITH NOWAIT;
		SET @sql = 'ALTER DATABASE [' + @DBName + '] SET AUTO_CLOSE OFF  WITH NO_WAIT
		;'
		RAISERROR(@sql,10,1)WITH NOWAIT;		
		IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;

	END	
	FETCH NEXT FROM FileName_cursor INTO @DBName, @page_verify_option, @is_auto_shrink_on, @is_auto_close_on
END
CLOSE FileName_cursor
DEALLOCATE FileName_cursor
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;




/****************************************************************************************************
							Error Logs Number and Cycle Job
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('	------------ Error Log Cofiguration ---------------',10,1) WITH NOWAIT;
DECLARE @lognum			INT 
DECLARE	@jobname		SYSNAME
DECLARE @enabled		TINYINT
DECLARE @startdate		INT
DECLARE @errnum			INT


SET @msg = '--Setting nubmer of error logs to 99'
RAISERROR (@msg,10,1) WITH NOWAIT;
SET @sql = '	EXEC xp_instance_regwrite N''hkey_local_machine'', N''software\microsoft\mssqlserver\mssqlserver'', N''numerrorlogs'', reg_dword, 99
;'
RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
RAISERROR ('',10,1) WITH NOWAIT;



SELECT 
	@jobname = j.name
	,@enabled = j.[enabled]
 FROM
	msdb.dbo.sysjobs j
	INNER JOIN msdb.dbo.sysjobsteps s ON j.job_id = s.job_id
WHERE
	s.command LIKE '%sp_cycle_errorlog%'

IF @jobname IS NOT NULL AND @CreateErrorLogJob = 1
BEGIN
	set @msg = '--	A job to cycle the error log already exists with name "' + @jobname +'" and is ' + CASE WHEN @enabled = 1 THEN 'Enabled' Else 'Disabled' End + '. This script will not script out another job.'
	RAISERROR (@msg,10,1) WITH NOWAIT;
END
ELSE IF @CreateErrorLogJob = 1
BEGIN
	RAISERROR ('',10,1) WITH NOWAIT;
	RAISERROR ('',10,1) WITH NOWAIT;
	RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
	RAISERROR ('/***							Creating cycle error job SQL Agent Job							  ***/',10,1) WITH NOWAIT;
	RAISERROR ('/*****************************************************************************************************/',10,1) WITH NOWAIT;
	RAISERROR ('',10,1) WITH NOWAIT;




	SET @sql = 'DECLARE @startdate	INT
	SET @startdate = CAST(CONVERT(VARCHAR(10),GETDATE(),112) AS INT)
	begin transaction
	DECLARE @returncode int
	SELECT @returncode = 0

	IF not exists (SELECT name FROM msdb.dbo.syscategories WHERE name=N''Fortified Data - Maintenance'' and category_class=1)
	begin
	exec @returncode = msdb.dbo.sp_add_category @class=N''job'', @type=N''local'', @name=N''Fortified Data - Maintenance''
	IF (@@error <> 0 or @returncode <> 0) goto quitwithrollback

	end'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
	RAISERROR ('',10,1) WITH NOWAIT;
	SET @sql = 'DECLARE @jobid binary(16)
	exec @returncode =  msdb.dbo.sp_add_job @job_name=N''DBA - Cycle Errorlog Nightly'', 
			@enabled=1, 
			@notify_level_eventlog=2, 
			@notify_level_email=0, 
			@notify_level_netsend=0, 
			@notify_level_page=0, 
			@delete_level=0, 
			@description=N''recycles the error log nighlty to minimize the number of log entries per file.'', 
			@category_name=N''Fortified Data - Maintenance'', 
			@owner_login_name=N''sa'', @job_id = @jobid output
	IF (@@error <> 0 or @returncode <> 0) goto quitwithrollback'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
	RAISERROR ('',10,1) WITH NOWAIT;

	SET @sql = 'exec @returncode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N''exec sp_cycle_errorlog'', 
			@step_id=1, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=1, 
			@os_run_priority=0, @subsystem=N''tsql'', 
			@command=N''exec sp_cycle_errorlog'', 
			@database_name=N''master'', 
			@flags=0
	IF (@@error <> 0 or @returncode <> 0) goto quitwithrollback
	exec @returncode = msdb.dbo.sp_update_job @job_id = @jobid, @start_step_id = 1
	IF (@@error <> 0 or @returncode <> 0) goto quitwithrollback'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)

	SET @sql = 'exec @returncode = msdb.dbo.sp_add_jobschedule @job_id=@jobid, @name=N''daily'', 
			@enabled=1, 
			@freq_type=4, 
			@freq_interval=1, 
			@freq_subday_type=1, 
			@freq_subday_interval=0, 
			@freq_relative_interval=0, 
			@freq_recurrence_factor=0, 
			@active_start_date= @startdate,
			@active_end_date=99991231, 
			@active_start_time=0, 
			@active_end_time=235959

	IF (@@error <> 0 or @returncode <> 0) goto quitwithrollback
	exec @returncode = msdb.dbo.sp_add_jobserver @job_id = @jobid, @server_name = N''(local)''
	IF (@@error <> 0 or @returncode <> 0) goto quitwithrollback
	commit transaction
	goto endsave
	quitwithrollback:
		IF (@@trancount > 0) rollback transaction
	endsave:
	;'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
	RAISERROR ('',10,1) WITH NOWAIT;


END
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;

/****************************************************************************************************
							SQL AGENT Job History
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('	------------ SQL AGENT Job History ---------------',10,1) WITH NOWAIT;
DECLARE @jobhistory_max_rows			INT
DECLARE @jobhistory_max_rows_per_job	INT


 EXECUTE master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',
                                         N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent',
                                         N'JobHistoryMaxRows',
                                         @jobhistory_max_rows OUTPUT,
                                         N'no_output'

  EXECUTE master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',
                                         N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent',
                                         N'JobHistoryMaxRowsPerJob',
                                         @jobhistory_max_rows_per_job OUTPUT,
                                         N'no_output'

SET @msg = '--Current history settings are Job History Max Rows = ' + cast(@jobhistory_max_rows AS VARCHAR(30)) + ' and Job History Max Rows Per Job = ' +  cast(@jobhistory_max_rows AS VARCHAR(30))
RAISERROR (@msg,10,1) WITH NOWAIT;
IF @jobhistory_max_rows != 5000 OR @jobhistory_max_rows != 100
BEGIN
	RAISERROR ('--Setting job history max rows to 5000 and job history max rows per job to 100.',10,1) WITH NOWAIT;
	SET @sql = '		exec msdb.dbo.sp_set_sqlagent_properties @jobhistory_max_rows = 5000, @jobhistory_max_rows_per_job = 100'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)
END
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;






/****************************************************************************************************
							DATABASE MAIL SETUP
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
IF @createMailProfile = 1
	RAISERROR ('	------------ DATABASE MAIL SETUP ---------------',10,1) WITH NOWAIT;
ELSE
	RAISERROR ('	------------ YOU ASKED TO SKIP DATABASE MAIL SETUP ---------------',10,1) WITH NOWAIT;

IF @createMailProfile = 1
BEGIN
	SET @sql = 'EXEC SP_CONFIGURE ''show advanced options'', 1
	RECONFIGURE WITH OVERRIDE
;
EXEC SP_CONFIGURE ''Database Mail XPs'', 1
	RECONFIGURE WITH OVERRIDE
;

'
	RAISERROR (@sql,10,1) WITH NOWAIT;
	IF (@runit=1) EXECUTE(@sql)


	IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysmail_account WHERE name = @mailAccountName)
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysmail_profile WHERE name = @sqlAgentdatbabaseMailProfile)
		BEGIN
			SET @sql = '-- Create a Database Mail account
EXECUTE msdb.dbo.sysmail_add_account_sp
	@account_name = '''+ @mailAccountName + ''',
	@description = ''Mail account for administrative e-mail.'',
	@email_address = ''' + @mailEmailAddress + ''',
	@port = ' + CAST(@mailPort AS VARCHAR(20)) + ',
	@replyto_address = ''' + @mailReplyAddress + ''',
	@display_name = ''' + @mailDisplayName + ''',
	@mailserver_name = ''' + @mailSMTP  +  ''',
	@enable_ssl = ' + cast(@mailUseSSL as char(1)) + '' +
	CASE WHEN @mailUserName IS NULL THEN ';'
		ELSE
			',
	@username = N''' + @mailUserName + ''',
	@password = N''' + ISNULL(@mailUserPassword,N'') + ''';'
		END
		RAISERROR (@sql,10,1) WITH NOWAIT;	
	IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;
	
		SET @sql = '-- Create a Database Mail profile
	EXECUTE msdb.dbo.sysmail_add_profile_sp
		@profile_name = ''' + @sqlAgentdatbabaseMailProfile + ''',
		@description = ''Profile used for DBA administrative mail.'' ;'
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)



		SET	@sql = '-- Add the account to the profile
	EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
		@profile_name = ''' + @sqlAgentdatbabaseMailProfile + ''',
		@account_name = ''' + @mailAccountName + ''',
		@sequence_number =1 ;'
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;

		SET @sql = '-- Grant access to the profile to all users in the msdb database
	EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
		@profile_name = ''' + @sqlAgentdatbabaseMailProfile + ''',
		@principal_name = ''public'',
		@is_default = 1 ;'
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;
		
		--CONFIGURE AGENT TO SEND EMAIL
		SET @sql = '-- CONFIGURE AGENT TO SEND EMAIL
	EXECUTE master.dbo.xp_instance_regwrite N''HKEY_LOCAL_MACHINE'', N''SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent'', N''UseDatabaseMail'', N''REG_DWORD'', 1
	;
	EXEC master.dbo.xp_instance_regwrite N''HKEY_LOCAL_MACHINE'', N''SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent'', N''DatabaseMailProfile'', N''REG_SZ'', N''' + @sqlAgentdatbabaseMailProfile + '''
	;'
		RAISERROR (@sql,10,1) WITH NOWAIT;
		IF (@runit=1) EXECUTE(@sql)
		RAISERROR ('',10,1) WITH NOWAIT;


		END
		ELSE
		BEGIN
			SET @msg = '--WARNING WARNING WARNING: An email profile with the name ''' + @sqlAgentdatbabaseMailProfile + ''' already exists therefore script is skipping the setup.'
			RAISERROR (@msg,10,1) WITH NOWAIT;
			RAISERROR ('',10,1) WITH NOWAIT;
		END
	END
	ELSE
	BEGIN
		SET @msg = '--WARNING WARNING WARNING:An email account with the name ''' + @mailAccountName + ''' already exists therefore script is skipping the setup.'
		RAISERROR (@msg,10,1) WITH NOWAIT;
		RAISERROR ('',10,1) WITH NOWAIT;
	END
END

SET @sql ='--Test DBMail
EXEC msdb.dbo.sp_send_dbmail
    @profile_name =  ''' + @sqlAgentdatbabaseMailProfile + ''',
    @recipients = ''' + @sqlAgentOperatorEmail + ''',
    @query = ''select @@servername'',
    @subject = ''Automated Success Message from Database Mail Creation Script'';
;'
RAISERROR (@sql,10,1) WITH NOWAIT;
IF (@runit=1) EXECUTE(@sql)
RAISERROR ('',10,1) WITH NOWAIT;




RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;


/****************************************************************************************************
							SQL AGENT ALERTS
****************************************************************************************************/
RAISERROR ('',10,1) WITH NOWAIT;
RAISERROR ('	------------ SQL AGENT ALERTS ---------------',10,1) WITH NOWAIT;

IF  @sqlAgentdatbabaseMailProfile IS NOT NULL AND (ISNULL(@sqlAgentOperatorEmail ,N'') = N'' OR ISNULL(@sqlAgentOperatorEmail,N'') = N'')
BEGIN
	RAISERROR ('	At least of the values for parameters @sqlAgentOperatorEmail and @sqlAgentOperatorEmail are null or empty. Please update these in order to set up SQL Agent Alerting.',10,1) WITH NOWAIT;
END 
ELSE
BEGIN

	IF @createMailProfile = 0 AND @sqlAgentdatbabaseMailProfile IS NOT NULL AND NOT EXISTS(SELECT 1 FROM msdb.dbo.sysmail_profile Where name = @sqlAgentdatbabaseMailProfile) 
	BEGIN
		RAISERROR ('',10,1) WITH NOWAIT;
		SET @msg = '-- WARNING-WARNING-WARNING ...	Cannot find Database Mail profile of "' +  @sqlAgentdatbabaseMailProfile + '" which was passed in as Parameter @sqlAgentdatbabaseMailProfile, please fix and run again so sp_add_operator statement will be created.'
		RAISERROR (@msg,10,1) WITH NOWAIT;
		RAISERROR (@msg,10,1) WITH NOWAIT;
		RAISERROR ('',10,1) WITH NOWAIT;
		RAISERROR ('',10,1) WITH NOWAIT;
	END
	ELSE
	BEGIN
		IF @sqlAgentdatbabaseMailProfile IS NOT NULL
		BEGIN
			RAISERROR ('--	Upating Database Mail profile.',10,1) WITH NOWAIT;
			--cehck the version of SQL
			declare @ver	varchar(30)
			declare @dot1	int
			declare @dot2	int
			declare @verdec	decimal(18,2)

			select @ver = cast(SERVERPROPERTY('productversion') as varchar(30))
			select @dot1 = CHARINDEX('.',@ver)
			select @dot2 = CHARINDEX('.',@ver,@dot1+1)
			select @verdec = cast(SUBSTRING(@ver,1,@dot2-1) as decimal(18,2))

			If @verdec >= 11.0
			BEGIN
				SET @sql = 'EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=1, 
		@alert_replace_runtime_tokens=1, 
		@databasemail_profile=N''' + @sqlAgentdatbabaseMailProfile + ''', 
		@use_databasemail=1'
			END
			ELSE --SQL 2008R2 and earlier
			BEGIN
				SET @sql = 'EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=1, 
		@alert_replace_runtime_tokens=1, 
		@email_profile=N''' + @sqlAgentdatbabaseMailProfile + ''''

			END

			RAISERROR (@sql,10,1) WITH NOWAIT;
			IF (@runit=1) EXECUTE(@sql)
			RAISERROR ('',10,1) WITH NOWAIT;
		END
		--IF @createMailProfile = 0 AND NOT EXISTS(SELECT 1 FROM msdb..sysoperators WHERE name = @sqlAgentOperatorName) AND @sqlAgentOperatorEmail IS NOT NULL
		IF NOT EXISTS(SELECT 1 FROM msdb..sysoperators WHERE name = @sqlAgentOperatorName) AND @sqlAgentOperatorEmail IS NOT NULL
		BEGIN
			RAISERROR ('--Setting up SQL Agent Operator.',10,1) WITH NOWAIT;
			SET @sql = 'EXEC msdb.dbo.sp_add_operator @name= ''' + @sqlAgentOperatorName +  ''', 
	@enabled=1, 
	@pager_days=0, 
	@email_address= N''' + @sqlAgentOperatorEmail + '''
;
'
			RAISERROR (@sql,10,1) WITH NOWAIT;
			IF (@runit=1) EXECUTE(@sql)
			RAISERROR ('',10,1) WITH NOWAIT;
			SET @createdOperator = 1
		END
		ELSE
			RAISERROR ('--	SQL Agent Operator does exist, will not be adding it.',10,1) WITH NOWAIT;
	END
		
	DECLARE @alertName				SYSNAME
	DECLARE @severityid				INT
	DECLARE @message_id             INT
	DECLARE @existingalertName		SYSNAME

	DECLARE curAlert CURSOR FAST_FORWARD LOCAL FOR 
		SELECT Name, severity, message_id FROM @alerts WHERE minsqlversion <= CONVERT(TINYINT, SUBSTRING(CONVERT(BINARY(4), @@MICROSOFTVERSION), 1, 1))

	OPEN curAlert
	FETCH NEXT FROM curAlert INTO @alertName, @severityid, @message_id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @createAlert = 0
		SET @updateAlert = 0
		SET @msg = '--	Setting up Alert for ' + @alertName + '.'
		RAISERROR (@msg,10,1) WITH NOWAIT;

		SET @existingalertName  = NULL
		IF @severityid IS NOT NULL
		BEGIN
			SELECT @existingalertName = LTRIM(RTRIM(name)) FROM msdb.dbo.sysalerts WHERE severity = @severityid
			IF @existingalertName IS NULL
			BEGIN
				SET @sql = 'EXEC msdb.dbo.sp_add_alert @name=N''' + @alertName+ ''', 
	@message_id=0, 
	@severity='  + CAST(@severityid  AS VARCHAR(12))    +', 
	@enabled=1, 
	@delay_between_responses=60,
	@include_event_description_in=1
;'
				SET @createAlert = 1
			END
			ELSE
			BEGIN
				SET @alertName = @existingalertName
				IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysalerts WHERE severity = @severityid AND enabled = 1)
				BEGIN
					SET @sql = 'EXEC msdb.dbo.sp_update_alert @name=N''' + @alertName+ ''', @enabled=1;
;'
					SET  @updateAlert = 1
				END
			END
		END

		IF @message_id IS NOT NULL
		BEGIN
			SELECT @existingalertName = LTRIM(RTRIM(name)) FROM msdb.dbo.sysalerts WHERE message_id = @message_id
			IF @existingalertName IS NULL
			BEGIN
				SET @sql = 'EXEC msdb.dbo.sp_add_alert @name=''' + @alertName +''', 
	@message_id='  + CAST(@message_id  AS VARCHAR(12))    +', 
	@severity=0, 
	@enabled=1, 
	@delay_between_responses=60,
	@include_event_description_in=1
;'
				SET @createAlert = 1
			END
			ELSE
			BEGIN
				SET @alertName = @existingalertName
				IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysalerts WHERE message_id = @message_id AND enabled = 1)
				BEGIN
					SET @sql = 'EXEC msdb.dbo.sp_update_alert @name=N''' + @alertName+ ''', @enabled=1;
;'
					SET  @updateAlert = 1
				END
			END
		END

		IF @createAlert = 1 OR @updateAlert = 1
		BEGIN
			RAISERROR (@sql,10,1) WITH NOWAIT;
			IF (@runit=1) EXECUTE(@sql)
			RAISERROR ('',10,1) WITH NOWAIT;
		END
		ELSE
		BEGIN
			SET @msg = '--	Alert exists already.'
			RAISERROR (@msg,10,1) WITH NOWAIT;
		END
			
		--MIKEZ: Still possible bug of both operator and alert existing but notification not existing
		IF @createdOperator = 1 or @createAlert = 1
		BEGIN						
			--ADD THE NOTIFICATION
			IF  @sqlAgentdatbabaseMailProfile IS NOT NULL
			BEGIN
				SET @sql = 'EXEC msdb.dbo.sp_add_notification @alert_name=N''' + @alertName + ''', @operator_name= N''' + @sqlAgentOperatorName + ''', @notification_method = 1
;'
				RAISERROR (@sql,10,1) WITH NOWAIT;
				IF (@runit=1) EXECUTE(@sql)
				RAISERROR ('',10,1) WITH NOWAIT;
			END
		END
		FETCH NEXT FROM curAlert INTO @alertName, @severityid, @message_id
	END
	CLOSE curAlert
	DEALLOCATE curAlert

	RAISERROR ('',10,1) WITH NOWAIT;
END

RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;




RAISERROR ('',10,1) WITH NOWAIT; 
RAISERROR ('----------------------------------------------------------------------------------------------------------------------',10,1) WITH NOWAIT;
RAISERROR ('',10,1) WITH NOWAIT;



GO
-----------------------------------------------------
--RAISERROR('NEED TO ADD THIS ALERT TO THE SCRIPT TO VERIFY',18,1) WITH NOWAIT
--NEED TO CHECK THIS AS IT IS FOR THE DEFAULT INSTANCE NOT A NAMED ONE.
IF NOT EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Blocking')
begin
	if exists (select name from msdb.dbo.sysjobs where name = N'DBA - Process_Monitor - Capture Active Running Processes')
		EXEC msdb.dbo.sp_add_alert @name=N'Blocking', 
				@message_id=0, 
				@severity=0, 
				@enabled=1, 
				@delay_between_responses=120, 
				@include_event_description_in=0, 
				@category_name=N'[Uncategorized]', 
				@performance_condition=N'General Statistics|Processes blocked||>|5', --do not need to specify instance name part of counter
				@job_name=N'DBA - Process_Monitor - Capture Active Running Processes'
END
GO

