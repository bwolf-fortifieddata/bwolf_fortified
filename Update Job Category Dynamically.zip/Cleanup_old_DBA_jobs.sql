use msdb
go
DECLARE @sql        NVARCHAR(MAX)
DECLARE @execute    BIT =  1        -- does not apply to daily and weekly maintenance rename
DECLARE @jobname    SYSNAME
DECLARE @category    SYSNAME

/********************************************************************************************************************
                    clean up �FD Monitor� jobs
********************************************************************************************************************/
DECLARE curJobs CURSOR FAST_FORWARD LOCAL FOR
SELECT
    j.name as JobName
    ,c.name as Category
    ,UPDATE_STMT = N'exec msdb.dbo.sp_update_job @job_name=N'''  + j.name + '''  , @new_name= N''' +     REPLACE(j.name, 'FD M', 'FD - M') + ''''
FROM
    msdb.dbo.sysjobs j
    INNER JOIN msdb.dbo.syscategories c on j.category_id = c.category_id

    WHERE
        j.name like 'FD Monitor%'
    /**********************************************************/
    /* REVIEW THIS FILTER AS IT MAY BE NEEDED AT CLIENTS WHO HAVE THE SAME NAMING CONVENTION ***/
        AND c.name like 'Fortified%'
    /**********************************************************/
ORDER BY
        j.name

        
PRINT ' '
PRINT 'Jobname                        Category                            Update Stmt'

OPEN curJobs
FETCH NEXT FROM curJobs INTO @jobname, @category, @sql
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @jobname +  '       ' + @category + '     '  + @sql

    IF @execute = 1
    BEGIN
        execute sp_executesql @sql
    END
    FETCH NEXT FROM curJobs INTO @jobname, @category, @sql
END
CLOSE curJobs
DEALLOCATE curJobs




-- CURSOR TO FIX UP ALL OTHER JOBS
DECLARE curJobs CURSOR FAST_FORWARD LOCAL FOR
SELECT
    j.name as JobName
    ,c.name as Category
    ,UPDATE_STMT = N'exec msdb.dbo.sp_delete_job @job_name=N'''  + j.name + '''  , @delete_unused_schedule=1'
FROM
    msdb.dbo.sysjobs j
    INNER JOIN msdb.dbo.syscategories c on j.category_id = c.category_id

    WHERE
        j.name like 'DBA%'
    /**********************************************************/
    /* REVIEW THIS FILTER AS IT MAY BE NEEDED AT CLIENTS WHO HAVE THE SAME NAMING CONVENTION ***/
        AND c.name like 'Fortified%'
    /**********************************************************/
ORDER BY
        j.name

        
PRINT ' '
PRINT 'Jobname                        Category                            Update Stmt'

OPEN curJobs
FETCH NEXT FROM curJobs INTO @jobname, @category, @sql
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @jobname +  '       ' + @category + '     '  + @sql

    IF @execute = 1
    BEGIN
        execute sp_executesql @sql
    END
    FETCH NEXT FROM curJobs INTO @jobname, @category, @sql
END
CLOSE curJobs
DEALLOCATE curJobs



USE [msdb]



IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'FD Monitor Statistics')
    EXEC msdb.dbo.sp_delete_job @job_name = N'FD Monitor Statistics', @delete_unused_schedule=1


IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'FD Monitor Plan Statistics')
    EXEC msdb.dbo.sp_delete_job @job_name = N'FD Monitor Plan Statistics', @delete_unused_schedule=1

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'FD Monitor Plan Results')
    EXEC msdb.dbo.sp_delete_job @job_name = N'FD Monitor Plan Results', @delete_unused_schedule=1