USE [FDDBA]
GO
SET NOCOUNT ON
DECLARE @TranLogFrequencyType					int  -- units to be used for frequency 4 = minutes, 8 = hours
DECLARE @TranLogBackupinterval					int  -- how often the transaction log backups should run @TranLogFrequencyType
DECLARE @DoNotScheduleTranLog					bit	 -- determines if the transaction log backup job should be scheduled, 1 = not scheduled.  This does not delete anything, just does not add a schedule.
DECLARE @BackupHistoryRetentionDay				int	  --how many days of backup history to keep, this will be used in the delete backup history job, set to 0 and step will not run
DECLARE @JobHistoryRetentionDay					int	  --how many days of SQL Agent job history to keep, this will be used in the delete job history job
DECLARE @NotificationOperator					sysname	-- Name of the operator to notify in case of job failure, if NULL no notifcation is set up
DECLARE @DailyMaintJobStartTime					int	--Time that the Daily Maint job should start, this matches the job schedule start time field. If NULL job is not created.
DECLARE @WeeklyMaintJobStartTime				int	--Time that the Weekly Maint job should start, this matches the job schedule start time field. If NULL job is not created.
DECLARE @DisableAllJobs							bit -- Option to disable all the jobs. You would do this if you wanted to create everything but not have it run, default is false
DECLARE @DoWeeklyFulls							bit -- Should we do daily DIfferential backups and a weekly full. Default is No
DECLARE @DoDailyDiffs							bit -- If @DoWeeklyFulls =1 then this parameter is checked to see if you still want daily differentials in the daily job
DECLARE @ExcludeBackupsFromDailyWeekly			bit -- Use this to exclude backups from both the weekly and daily jobs
DECLARE @IndexMaintUseTempDB					bit -- turn "sort in tempdb" to YES for index maintenance if the @SortintempDb parameter does not already exist
DECLARE @BufferCount							int -- Set this a number greater than 0 to have it added to the full backup job. If NULL or <1 then it will not be added
DECLARE @DailyJobScheduleName					nvarchar(128) -- Name of the daily schedule, i.e. "Mon to Sat"
DECLARE @DailyJobScheduleFreqinterval			int -- interval to use for the daily job, should match @freq_interval paramter values as noted in BOL https://msdn.microsoft.com/en-us/library/ms366342.aspx
DECLARE @WeeklyJobScheduleName					nvarchar(128) -- Name of the daily schedule, i.e. "Weekly"
DECLARE @WeeklyJobScheduleFreqinterval			int -- interval to use for the daily job, should match @freq_interval paramter values as noted in BOL https://msdn.microsoft.com/en-us/library/ms366342.aspx
DECLARE @IndexMaintWaitAtLowPriortyTime			int	   -- If value is greater than 0 will add the WAIT_AT_LOW_PRIORITY option to index maintenance with KILL = SELF https://docs.microsoft.com/en-us/sql/t-sql/statements/alter-index-transact-sql?view=sql-server-2017
DECLARE @DiffJobChangeBackupType				bit  --Change the differential backup job to include the @ChangeBackupType ='Y' parmeter/value pair.
DECLARE @UpdateBlockAndMaxTrnsfrSize			bit  --update the full backup to include max setting for block and Max Transfer size
	--EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Mon to Sat', 
	--		@enabled=1, 
	--		@freq_type=8, 
	--		@freq_interval=126,

/************************************************************************************
						CONFIGURE PARAMETERS 
************************************************************************************/
SET @TranLogFrequencyType				= 8			-- units to be used for frequency 4 = minutes, 8 = hours
SET @TranLogBackupinterval				= 24		--how often the transaction log backups should run in @TranLogFrequencyType
SET @DoNotScheduleTranLog				= 1			-- determines if the transaction log backup job should be scheduled, 1 = not scheduled. This does not delete anything, just does not add a schedule.
SET @BackupHistoryRetentionDay			= 90		--how many days of backup history to keep, this will be used in the delete backup history job, set to 0 and step will not run
SET @JobHistoryRetentionDay				= 60		--how many days of SQL Agent job history to keep, this will be used in the delete job history job
SET @NotificationOperator				= 'DBA'		--N'FDDBA'	--Name of the operator to notify in case of job failure, if NULL no notifcation is set up
SET @DailyMaintJobStartTime				= 201500	--Time that the Daily Maint job should start, this matches the job schedule start time field.  NULL job is not created.
SET @WeeklyMaintJobStartTime			= 201500	--Time that the Weekly Maint job should start, this matches the job schedule start time field. If NULL job is not created.
SET @DisableAllJobs						= 0			-- Option to disable all the jobs. You would do this if you wanted to create everything but not have it run, default is 0 (No)
SET @DoWeeklyFulls						= 1			-- Should we do daily DIfferential backups and a weekly full. Default is 0 (No)
SET @DoDailyDiffs						= 0			 -- If @DoWeeklyFulls =1 then this parameter is checked to see if you still want daily differentials in the daily job
SET @ExcludeBackupsFromDailyWeekly		= 0 -- Use this to exclude backups from both the weekly and daily jobs
SET @IndexMaintUseTempDB				= 1			-- turn "sort in tempdb" to YES for index maintenance if the @SortintempDb parameter does not already exist
SET @BufferCount						= 50		-- Set this a number greater than 0 to have it added to the full backup job. If NULL or <1 then it will not be added
SET @IndexMaintWaitAtLowPriortyTime		= 10		-- If value is greater than 0 will add the WAIT_AT_LOW_PRIORITY option to index maintenance with KILL = SELF https://docs.microsoft.com/en-us/sql/t-sql/statements/alter-index-transact-sql?view=sql-server-2017
-- These are defaulted to Run the daily Monday to Saturday and the weekly on Sunday, use these to change the frequency
SET @DailyJobScheduleName			= N'Mon to Sat' -- Name of the daily schedule, i.e. "Mon to Sat"
SET @DailyJobScheduleFreqinterval	= 126 --Mon to Sat , Sun To Friday = 63-- interval to use for the daily job, should match @freq_interval paramter values as noted in BOL https://msdn.microsoft.com/en-us/library/ms366342.aspx
SET @WeeklyJobScheduleName			= N'Weekly Sunday' -- Name of the daily schedule, i.e. "Weekly", Saturday = 64
SET @WeeklyJobScheduleFreqinterval	 = 1 -- 1 = Sunday, 64 = Saturday -- interval to use for the daily job, should match @freq_interval paramter values as noted in BOL https://msdn.microsoft.com/en-us/library/ms366342.aspx
SET @DiffJobChangeBackupType			= 1 --Change the differential backup job to include the @ChangeBackupType ='Y' parmeter/value pair.
SET @UpdateBlockAndMaxTrnsfrSize			= 1 --update the full backups to include max setting for block and Max Transfer size
/************************************************************************************
THIS IS AN EXAMPLE OF SETTING THE TRAN LOG FREQUENCY AND TYPE BASED ON THE SERVER NAME
SO IT DOES EVERY X HOURS FOR DEV, QA AND UAT AND EVERY X MintUES FOR PROD
You can also add something similar for @NotificationOperator for those
environments that may not be watched by a monitoring tool
************************************************************************************/
/*
SELECT @TranLogFrequencyType  =  CASE  When @@servername like '%DEV%' OR
					@@servername like '%QA%'OR @@servername like '%UAT%' THEN 8
					ELSE 4 END
SELECT @TranLogBackupinterval = CASE  When @@servername like '%DEV%' OR
					@@servername like '%QA%'OR @@servername like '%UAT%' THEN 24
						ELSE 72 END
*/


--Get a list of jobs that we will work on based on the description

IF OBJECT_ID('tempdb..#joblist') IS NOT NULL
	DROP TABLE #joblist 

CREATE TABLE #joblist (jobname   SYSNAME, jobid UNIQUEIDENTIFIER)
INSERT intO #joblist(jobname, jobid)
SELECT	
	j.name
	,j.job_id
 FROM
	msdb.dbo.sysjobs j 
 WHERE
	1=1
	AND j.[description] like '%Source: https://ola.hallengren.com'



DECLARE @rows					int
DECLARE @msg					VARCHAR(2048)
DECLARE @jobid					UNIQUEIDENTIFIER
DECLARE @jobname				SYSNAME
DECLARE @intdate				int
DECLARE @schedule_id			int
DECLARE @cmd					NVARCHAR(MAX)
DECLARE @stepname				SYSNAME
DECLARE @schedulename			SYSNAME
DECLARE @tempvc					VARCHAR(500)
DECLARE @ReturnCode				int
DECLARE @sql					NVARCHAR(500)
DECLARE @step					int
DECLARE	@FullStmt				VARCHAR(256)


DECLARE @ver	varchar(30)
DECLARE @dot1	int
DECLARE @dot2	int
DECLARE @verdec	decimal(18,2)

SET @ver = cast(SERVERPROPERTY('productversion') as varchar(30))
SET @dot1 = CHARINDEX('.',@ver)
SET @dot2 = CHARINDEX('.',@ver,@dot1+1)
SET @verdec = cast(SUBSTRING(@ver,1,@dot2-1) as decimal(18,2))
/************************************************************************************
Lets clean up those output file names removing the job id, who wants to see that anyway
************************************************************************************/
UPDATE t
  SET	t.output_file_name = 
		Case When j.jobname like 'DatabaseBackup%' Then REPLACE(t.output_file_name, N'_$(ESCAPE_SQUOTE(JOBID))',REPLACE(SUBSTRING(j.jobname,15,LEN(j.jobname)),' - ','_'))
			 When j.jobname like 'DatabaseintegrityCheck%' THEN REPLACE(t.output_file_name, N'_$(ESCAPE_SQUOTE(JOBID))',REPLACE(SUBSTRING(j.jobname,23,LEN(j.jobname)),' - ','_'))
		Else  REPLACE(t.output_file_name, N'_$(ESCAPE_SQUOTE(JOBID))',N'')
		END

 FROM
	 msdb.dbo.sysjobsteps t
	 inner join #joblist j on t.job_id = j.jobid
 WHERE
	t.output_file_name LIKE N'%$(ESCAPE_SQUOTE(JOBID))%'

 SET @rows = @@ROWCOUNT
 SET @msg = CAST(@rows AS VARCHAR(30)) + ' job steps were updated to remove "JOBID" from output file name.'
 RAISERROR(@msg, 10,1) WITH NOWAIT;


 
/************************************************************************************
	Change the index maintenance job USER_DATABASES to ALL_DATABASES
************************************************************************************/
RAISERROR(N'',10,1) WITH NOWAIT;
IF (SELECT count(*) FROM msdb.dbo.sysjobs where name IN('IndexOptimize - ALL_DATABASES' ,N'IndexOptimize - USER_DATABASES')) = 2
BEGIN
	SELECT @jobid=  job_id FROM msdb.dbo.sysjobs_view WHERE name = N'IndexOptimize - USER_DATABASES'
	IF @jobid IS NOT NULL
	BEGIN
		RAISERROR('There appears to be a ''IndexOptimize - ALL_DATABASES'' and  ''IndexOptimize - USER_DATABASES'' job, so dropping the [IndexOptimize - USER_DATABASES] job.',10,1) WITH NOWAIT;
		EXEC msdb.dbo.sp_delete_job @job_name = N'IndexOptimize - USER_DATABASES', @delete_unused_schedule=1
		DELETE FROM #joblist WHERE jobid = @jobid
	END
END 


SET @jobid = NULL
SELECT @jobid = jobid FROM #joblist WHERE jobname like '%IndexOptimize - USER_DATABASES%' 
IF @jobid IS NOT NULL
BEGIN
	SELECT 
		@cmd = REPLACE(command, N'USER_DATABASES', N'ALL_DATABASES') 
		,@stepname = REPLACE(step_name, N'USER_DATABASES', N'ALL_DATABASES') 
	 FROM 
		msdb.dbo.sysjobsteps 
	 WHERE 
		job_id = @jobid 
		AND step_id = 1
	EXECUTE msdb.dbo.sp_update_job @job_id = @jobid, @new_name = N'IndexOptimize - ALL_DATABASES'
	EXECUTE msdb.dbo.sp_update_jobstep @job_id = @jobid, @step_id =1, @command = @cmd,@step_name = @stepname
	RAISERROR(N'Job IndexOptimize - USER_DATABASES was renamed and updated to include ALL_DATABASES.',10,1) WITH NOWAIT;
	DELETE FROM #joblist  WHERE jobname like '%IndexOptimize - USER_DATABASES%' 

END
ELSE
BEGIN
	SET @msg = 'Could not find job with name like ''IndexOptimize - USER_DATABASES'', skipping update/rename of the job.'
	RAISERROR(@msg, 10,1) WITH NOWAIT;
END



/************************************************************************************
	Change the index maintenance job to do stats updates
************************************************************************************/
RAISERROR(N'',10,1) WITH NOWAIT;
SET @jobid = NULL
SELECT 
	@jobid = j.job_id 
 FROM 
	msdb.dbo.sysjobs j 
	inner join msdb.dbo.sysjobsteps s on j.job_id = s.job_id

WHERE 
	j.name like '%IndexOptimize - ALL_DATABASES%' 
	AND command NOT LIKE '%@UpdateStatistics%'
	AND s.step_name != N'Check for Failure'

IF @jobid IS NOT NULL
BEGIN
	SELECT 
		@cmd = REPLACE(command, N'@Databases =', N' @UpdateStatistics = ''ALL'', @OnlyModifiedStatistics = ''Y'', @Databases =') 
	 FROM 
		msdb.dbo.sysjobsteps 
	 WHERE 
		job_id = @jobid 
		AND step_id = 1
	
	EXECUTE msdb.dbo.sp_update_jobstep @job_id = @jobid, @step_id =1, @command = @cmd
	RAISERROR(N'Job IndexOptimize - ALL_DATABASES was updated to include STATSITCS updates.',10,1) WITH NOWAIT;
END
ELSE
BEGIN
	SET @msg = 'Job ''IndexOptimize - ALL_DATABASES'' has already been updated to include stats or does not exist, skipping adding stats update code to job.'
	RAISERROR(@msg, 10,1) WITH NOWAIT;
END

/************************************************************************************
	Change the index maintenance job To SORTintEMPDB if set to yes
************************************************************************************/
IF @IndexMaintUseTempDB = 1
BEGIN
	DECLARE curJOBS CURSOR FAST_FORWARD LOCAL FOR
	SELECT job_id FROM msdb..sysjobs WHERE name like '%IndexOptimize%'
	OPEN curJOBS
	FETCH NEXT FROM curJOBS intO @jobid
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS(
					SELECT 1
					 FROM 
						msdb..sysjobs j
						INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
					 WHERE 
						j.job_id = @jobid
						AND s.command like '%IndexOptimize%'
						AND s.command NOT LIKE '%@Sortintempdb%'
						AND s.step_name != N'Check for Failure'
		)
		SELECT @sql ='use msdb 
Exec sp_update_jobstep @job_name = N''' +  j.name + ''', @step_id = ' + CAST(step_id AS VARCHAR(5)) + ', @command = N''' +REPLACE(REPLACE(s.command,'''',''''''), '@Databases','@Sortintempdb = ''''Y'''', @Databases') + ''''  
	 	 FROM 
			msdb..sysjobs j
			INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
		 WHERE 
			j.job_id = @jobid

		EXEC sp_executesql @sql
		FETCH NEXT FROM curJOBS intO @jobid
	END
	CLOSE curJOBS
	DEALLOCATE curJOBS
END

/******************************************************************************************************************
	Change the index maintenance job to incude WAIT_AT_LOW_PRIORITY if version is 
	SQL Server 2014 (12.x) or later and the parameter @IndexMaintWaitAtLowPriortyTime greater than 0
******************************************************************************************************************/

IF ISNULL(@IndexMaintWaitAtLowPriortyTime ,0)  > 0 AND @verdec >= 12
BEGIN
	DECLARE curJOBS CURSOR FAST_FORWARD LOCAL FOR
	SELECT job_id FROM msdb..sysjobs WHERE name like '%IndexOptimize%'
	OPEN curJOBS
	FETCH NEXT FROM curJOBS intO @jobid
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS(
					SELECT 1
					 FROM 
						msdb..sysjobs j
						INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
					 WHERE 
						j.job_id = @jobid
						AND s.command like '%IndexOptimize%'
						AND s.command NOT LIKE '%@WaitAtLowPriorityMaxDuration%'
						AND s.step_name LIKE '%IndexOptimize - ALL_DATABASES%'
		)
		BEGIN
			SELECT @cmd = '@WaitAtLowPriorityMaxDuration = ' + CAST(@IndexMaintWaitAtLowPriortyTime AS VARCHAR(20)) + ', @WaitAtLowPriorityAbortAfterWait =''SELF'' , @Databases'
			 FROM 
				msdb..sysjobs j
				INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
			 WHERE 
				j.job_id = @jobid
				AND s.command like '%IndexOptimize%'
				AND s.command NOT LIKE '%@WaitAtLowPriorityMaxDuration%'
				AND s.step_name LIKE '%IndexOptimize - ALL_DATABASES%'
			PRint '@cmd:' + @cmd	

			SELECT @sql ='use msdb 
	  Exec sp_update_jobstep @job_name = N''' +  j.name + ''', @step_id = ' + CAST(step_id AS VARCHAR(5)) + ', @command = N''' + REPLACE(REPLACE(s.command, '@Databases',@cmd),'''','''''') + '''' 
			FROM 
				msdb..sysjobs j
				INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
			 WHERE 
				j.job_id = @jobid
				AND s.command like '%IndexOptimize%'
				AND s.command NOT LIKE '%@WaitAtLowPriorityMaxDuration%'
				AND s.step_name LIKE '%IndexOptimize - ALL_DATABASES%'

	 	
			PRint @sql
			EXEC sp_executesql @sql
		END
		FETCH NEXT FROM curJOBS intO @jobid
	END
	CLOSE curJOBS
	DEALLOCATE curJOBS
END


/************************************************************************************
	Change the DIFF maintenance job To include @ChangeBackupType = 'Y'
************************************************************************************/

DECLARE curJOBS CURSOR FAST_FORWARD LOCAL FOR
SELECT job_id FROM msdb..sysjobs WHERE name like '%Backup%DIFF%' AND @DiffJobChangeBackupType = 1
OPEN curJOBS
FETCH NEXT FROM curJOBS intO @jobid
WHILE @@FETCH_STATUS = 0
BEGIN
	IF EXISTS(
				SELECT 1
					FROM 
					msdb..sysjobs j
					INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
					WHERE 
					j.job_id = @jobid
					AND s.command like '%DIFF%'
					AND s.command NOT LIKE '%@BackupType%'
	)
	SELECT @sql ='use msdb 
Exec sp_update_jobstep @job_name = N''' +  j.name + ''', @step_id = ' + CAST(step_id AS VARCHAR(5)) + ', @command = N''' +REPLACE(REPLACE(s.command,'''',''''''), '@BackupType =','@ChangeBackupType = ''''Y'''',@BackupType =') + ''''  
	 	FROM 
		msdb..sysjobs j
		INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
		WHERE 
		j.job_id = @jobid
	RAISERROR('Differential backup job - adding parameter @ChangeBacakupType =Y.',10,1) WITH NOWAIT;
	EXEC sp_executesql @sql
	FETCH NEXT FROM curJOBS intO @jobid
END
CLOSE curJOBS
DEALLOCATE curJOBS

/************************************************************************************
	Change the FULL backup to inlcude maxtransfersize and block size
	and optional buffer count- based on buffer count param
************************************************************************************/

DECLARE curJOBSFull CURSOR FAST_FORWARD LOCAL FOR
SELECT job_id FROM msdb..sysjobs WHERE name like '%Backup%FULL%' AND name NOT LIKE '%SYSTEM_DATABASES%' AND @UpdateBlockAndMaxTrnsfrSize = 1
OPEN curJOBSFull
FETCH NEXT FROM curJOBSFull intO @jobid
WHILE @@FETCH_STATUS = 0
BEGIN
	IF EXISTS(
				SELECT 1
					FROM 
					msdb..sysjobs j
					INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
					WHERE 
					j.job_id = @jobid
					AND s.command like '%FULL%'
					AND s.command NOT LIKE '%@BlockSize%'
	)
	BEGIN
		SET @FullStmt = CASE WHEN ISNULL(@BufferCount,0) < 1 Then '@BlockSize=65536, @MaxTransferSize=4194304, @Verify ='
						ELSE '@BufferCount = ' + CAST(@BufferCount AS VARCHAR(30)) + ', @BlockSize=65536, @MaxTransferSize=4194304, @Verify =' END

		SELECT @sql =   'use msdb 
Exec sp_update_jobstep @job_name = N''' +  j.name + ''', @step_id = ' + CAST(step_id AS VARCHAR(5)) + ', @command = N''' +REPLACE(REPLACE(s.command,'''',''''''), '@Verify =', @FullStmt) + ''''  
	 		FROM 
			msdb..sysjobs j
			INNER JOIN msdb..sysjobsteps s on j.job_id = s.job_id
			WHERE 
			j.job_id = @jobid
		SELECT  TOP 1 @msg = 'Job ' + name + ' - adding performance parameters.' from msdb.dbo.sysjobs where job_id = @jobid
		RAISERROR(@msg,10,1) WITH NOWAIT;
		EXEC sp_executesql @sql
	END
	FETCH NEXT FROM curJOBSFull intO @jobid
END
CLOSE curJOBSFull
DEALLOCATE curJOBSFull

/************************************************************************************
				Set up the Transaction Log Job Schedule
************************************************************************************/
RAISERROR(N'',10,1) WITH NOWAIT;
IF ISNULL(@DoNotScheduleTranLog,0) = 0
BEGIN
	SET @jobid = NULL
	SELECT @jobid = jobid FROM #joblist WHERE jobname like '%DatabaseBackup - USER_DATABASES - LOG%' 
	IF @jobid IS NOT NULL
	BEGIN
		--check to see if schedule exists and it is enabled
		IF NOT EXISTS (SELECT 1   FROM msdb.dbo.sysjobs j inner join msdb.dbo.sysjobschedules s ON j.job_id = s.job_id inner join msdb.dbo.sysschedules sch ON s.schedule_id = sch.schedule_id
							WHERE j.job_id = @jobid AND sch.[enabled] = 1 )
		BEGIN
			SET @schedulename = N'Every ' + CAST(@TranLogBackupinterval AS NVARCHAR(10)) + 
					CASE @TranLogFrequencyType WHEN 8 THEN ' Hours' ELSE ' Minutes' END
			EXEC msdb.dbo.sp_add_jobschedule @job_id=@jobid, @name=@schedulename, 
			@enabled=1, 
			@freq_type=4, 
			@freq_interval=1, 
			@freq_subday_type=@TranLogFrequencyType, 
			@freq_subday_interval=@TranLogBackupinterval, 
			@freq_relative_interval=0, 
			@freq_recurrence_factor=1, 
			@active_start_date=@intdate, 
			@active_end_date=99991231, 
			@active_start_time=0, 
			@active_end_time=235959, @schedule_id = @schedule_id OUTPUT
			SET @msg = 'Schedule Id ' + CAST(@schedule_id AS VARCHAR(30)) + '  is now being used for job ''DatabaseBackup - USER_DATABASES - LOG''.'
			RAISERROR(@msg, 10,1) WITH NOWAIT;
		END
		ELSE
			RAISERROR('Job "DatabaseBackup - USER_DATABASES - LOG" is already scheduled so a new schedule will not be added.',10,1) WITH NOWAIT;
	END
	ELSE
	BEGIN
		SET @msg = 'Could not find job with name like ''DatabaseBackup - USER_DATABASES - LOG'', skipping adding of job schedule.'
		RAISERROR(@msg, 10,1) WITH NOWAIT;
	END
END
ELSE
BEGIN
	SET @msg = 'Skipping set up of Transaction log job schedule.'
	RAISERROR(@msg, 10,1) WITH NOWAIT;
END


/************************************************************************************
		Set up the backup history delete Job retention period
************************************************************************************/
RAISERROR(N'',10,1) WITH NOWAIT;
SET @jobid = NULL
SELECT @jobid = jobid FROM #joblist WHERE jobname like '%delete_backuphistory%' AND ISNULL(@BackupHistoryRetentionDay,0) > 0 
IF @jobid IS NOT NULL
BEGIN
	--if the number is positive set it back to negative 
	If @BackupHistoryRetentionDay > 0 
		SET @BackupHistoryRetentionDay = @BackupHistoryRetentionDay * -1

	IF EXISTS(SELECT 1 FROM msdb.dbo.sysjobsteps s WHERE s.job_id = @jobid AND CHARINDEX(',-30,',s.command,1) > 1)
	BEGIN
		SET @tempvc = ',' +  CAST(@BackupHistoryRetentionDay AS VARCHAR(5)) + ','
		SELECT 
			@cmd = REPLACE(command, N',-30,', @tempvc) 	
		 FROM 
			msdb.dbo.sysjobsteps 
		 WHERE 
			job_id = @jobid 
			AND step_id = 1
		EXECUTE msdb.dbo.sp_update_jobstep @job_id = @jobid, @step_id =1, @command = @cmd
		RAISERROR(N'Job "delete_backuphistory" has been updated.',10,1) WITH NOWAIT;
	END
	ELSE
		RAISERROR(N'Job "delete_backuphistory" appears to already have its retention value updated to something that is not 30 so I will not change it..',10,1) WITH NOWAIT;
END
ELSE
BEGIN
	SET @msg = 'Could not find job with name like ''delete_backuphistory'' or @BackupHistoryRetentionDay <1. Skipping updating job step.'
	RAISERROR(@msg, 10,1) WITH NOWAIT;
END


/************************************************************************************
		Set up the Agent Job history retention period
************************************************************************************/
RAISERROR(N'',10,1) WITH NOWAIT;
SET @jobid = NULL
SELECT @jobid = jobid FROM #joblist WHERE jobname like '%purge_jobhistory%'  AND ISNULL(@JobHistoryRetentionDay,0) > 0
IF @jobid IS NOT NULL
BEGIN
	--if the number is positive set it back to negative 
	If @JobHistoryRetentionDay > 0 
		SET @JobHistoryRetentionDay = @JobHistoryRetentionDay * -1
	SET @tempvc = ',' +  CAST(@JobHistoryRetentionDay AS VARCHAR(5)) + ','
	IF EXISTS(SELECT 1 FROM msdb.dbo.sysjobsteps s WHERE s.job_id = @jobid AND step_id = 1 AND CHARINDEX(',-30,',s.command,1) > 1)
	BEGIN
		SELECT 
			@cmd = REPLACE(command, N',-30,', @tempvc) 	
		 FROM 
			msdb.dbo.sysjobsteps 
		 WHERE 
			job_id = @jobid 
			AND step_id = 1
		EXECUTE msdb.dbo.sp_update_jobstep @job_id = @jobid, @step_id =1, @command = @cmd
		RAISERROR(N'Job "purge_jobhistory" has been updated.',10,1) WITH NOWAIT;
	END
	ELSE
		RAISERROR(N'Job "purge_jobhistory" appears to already have its retention value updated so I will not change it..',10,1) WITH NOWAIT;
	--now add the schedule if one does not exists and is enabled
END
ELSE
BEGIN
	SET @msg = 'Could not find job with name like ''purge_jobhistory'' or @JobHistoryRetentionDay < 1. Skipping updating job step.'
	RAISERROR(@msg, 10,1) WITH NOWAIT;
END






/************************************************************************************
		Set up the Daily Maintenance conductor job and schedule 
************************************************************************************/
	RAISERROR('', 10,1) WITH NOWAIT;
IF @DailyMaintJobStartTime IS NOT NULL
BEGIN
	IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'FD - Maintenance-Daily')
	BEGIN
		SET @jobid = NULL
		BEGIN TRANSACTION
		SELECT @ReturnCode = 0
	
		IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Fortified Data - Maintenance' AND category_class=1)
		BEGIN
		EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Fortified Data - Maintenance'
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

		END

		EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FD - Maintenance-Daily', 
				@enabled=1, 
				@notify_level_eventlog=0, 
				@notify_level_email=2, 
				@notify_level_netsend=0, 
				@notify_level_page=0, 
				@delete_level=0, 
				@description=N'Runs the daily maintenance jobs', 
				@category_name=N'Fortified Data - Maintenance', 
				@owner_login_name=N'sa', 
				@notify_email_operator_name= @NotificationOperator,
				@job_id = @jobid OUTPUT
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
	
		Set @step = 0

		IF @ExcludeBackupsFromDailyWeekly = 0
		BEGIN
			SET @step = @step + 1
			EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Backup System Database', 
					@step_id=@step, 
					@cmdexec_success_code=0, 
					@on_success_action=3, 
					@on_success_step_id=0, 
					@on_fail_action=3, 
					@on_fail_step_id=0, 
					@retry_attempts=0, 
					@retry_interval=0, 
					@os_run_priority=0, @subsystem=N'TSQL', 
					@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''DatabaseBackup - SYSTEM_DATABASES - FULL''   ,@par_waitinterval = ''00:00:15''   ,@JobCompletionStatus = NULL', 
					@database_name=N'FDDBA', 
					@flags=0
			IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
		END
		IF @ExcludeBackupsFromDailyWeekly = 0
		BEGIN
			If @DoWeeklyFulls = 1 
			BEGIN
				IF ISNULL(@DoDailyDiffs,0) = 1 
				BEGIN
					SET @step = @step + 1
					EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Differential Backup User Databases', 
							@step_id=@step, 
							@cmdexec_success_code=0, 
							@on_success_action=3, 
							@on_success_step_id=0, 
							@on_fail_action=3, 
							@on_fail_step_id=0, 
							@retry_attempts=0, 
							@retry_interval=0, 
							@os_run_priority=0, @subsystem=N'TSQL', 
							@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''DatabaseBackup - USER_DATABASES - DIFF''   ,@par_waitinterval = ''00:00:30''   ,@JobCompletionStatus = NULL', 
							@database_name=N'FDDBA', 
							@flags=0
					IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
				END
				ELSE
					RAISERROR('@DoDailyDiffs was set to 0, so Diff was not added to daily schedule job',10,1) WITH NOWAIT;
			END
			ELSE
			BEGIN
				SET @step = @step + 1
				EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Full Backup User Databases', 
						@step_id=2, 
						@cmdexec_success_code=0, 
						@on_success_action=3, 
						@on_success_step_id=0, 
						@on_fail_action=3, 
						@on_fail_step_id=0, 
						@retry_attempts=0, 
						@retry_interval=0, 
						@os_run_priority=0, @subsystem=N'TSQL', 
						@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''DatabaseBackup - USER_DATABASES - FULL''   ,@par_waitinterval = ''00:00:30''   ,@JobCompletionStatus = NULL', 
						@database_name=N'FDDBA', 
						@flags=0
				IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
			END
		END

		SET @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'integrity Check System Databases', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''DatabaseintegrityCheck - SYSTEM_DATABASES''   ,@par_waitinterval = ''00:00:30''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
		
		SET @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Index Maintenance All Databases', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''IndexOptimize - ALL_DATABASES''   ,@par_waitinterval = ''00:00:30''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

		SET @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Check for failures', 
			@step_id=@step, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, @subsystem=N'TSQL', 
			@command=N'DECLARE @jobid		uniqueidentifier
	DECLARE @rundate	int
	DECLARE @runtime	int
	DECLARE @startdt		DATETIME
	DECLARE @msg		VARCHAR(2048)
	--GET THE JOB ID
	SELECT @jobid =  CONVERT(uniqueidentifier,$(ESCAPE_NONE(JOBID)))
	PRint ''Job Id is: '' + ISNULL(CAST(@jobid as varchar(50)), ''nuLL'')
	--GET THE LATEST RUNTIME INFORMATION FROM ACTIVITY
	select 
		 @startdt = a.start_execution_date
		,@rundate =  CAST(convert(CHAR(8), a.start_execution_date,112) AS int)
		,@runtime =  CAST(REPLACE(convert(char(8), a.start_execution_date,108),'':'','''') AS int)
	 from
		sysjobactivity a
	Where
		a.job_id = @jobid
	--CHECK FOR ERRORS AND IF ANY OCCURRED RAISE AN ERROR TO FAIL THIS STEP
	IF EXISTS(
		SELECT 
			1
		 FROM
			sysjobhistory h
		 WHERE
			h.job_id = @jobid
			AND dbo.agent_datetime(h.run_date, h.run_time) >= @startdt
			AND run_status = 0 --failed
		)
	BEGIN
		PRint ''Failure found, returning Error to job step''
		RAISERROR(''One or more job steps failed, please investigate'',11,1) WITH NOWAIT;
	END
	ELSE
		PRint ''No step failures found :)''', 
			@database_name=N'msdb', 
			@flags=0

		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
		EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobid, @start_step_id = 1
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback


		EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobid, @name= @DailyJobScheduleName, 
				@enabled=1, 
				@freq_type=8, 
				@freq_interval= @DailyJobScheduleFreqinterval, 
				@freq_subday_type=1, 
				@freq_subday_interval=0, 
				@freq_relative_interval=0, 
				@freq_recurrence_factor=1, 
				@active_start_date= @intdate, 
				@active_end_date=99991231, 
				@active_start_time= @DailyMaintJobStartTime, 
				@active_end_time=235959
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
		EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobid, @server_name = N'(local)'
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
		COMMIT TRANSACTION
		GOTO EndSave
		QuitWithRollback:
			IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
		EndSave:
		RAISERROR('Job "FD - Maintenance-Daily" creation completed. If any errors occured prior to this message pleae investigate.',10,1) WITH NOWAIT;
	END
	ELSE
		RAISERROR('Job "FD - Maintenance-Daily" already exits and will not be created by this script.',10,1) WITH NOWAIT;
END
ELSE
	RAISERROR('Paramerter @DailyMaintJobStartTime is null so not creating Job "FD - Maintenance-Daily".',10,1) WITH NOWAIT;



/************************************************************************************
		Set up the Weekly  Maintenance conductor job and schedule 
************************************************************************************/
RAISERROR('', 10,1) WITH NOWAIT;
IF @WeeklyMaintJobStartTime IS NOT NULL
BEGIN
	IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysjobs WHERE name = N'FD - Maintenance-Weekly')
	BEGIN
		SET @jobid = NULL
		BEGIN TRANSACTION
		SELECT @ReturnCode = 0
	
		IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Fortified Data - Maintenance' AND category_class=1)
		BEGIN
		EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Fortified Data - Maintenance'
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2
		END

		EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FD - Maintenance-Weekly', 
				@enabled=1, 
				@notify_level_eventlog=0, 
				@notify_level_email=2, 
				@notify_level_netsend=0, 
				@notify_level_page=0, 
				@delete_level=0, 
				@description=N'Runs the weekly and daily maintenance jobs', 
				@category_name=N'Fortified Data - Maintenance', 
				@owner_login_name=N'sa', 
				@notify_email_operator_name=@NotificationOperator, 
				@job_id = @jobid OUTPUT
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2

		Set @step = 0
		IF @ExcludeBackupsFromDailyWeekly = 0
		BEGIN
			If @DoWeeklyFulls = 1
			BEGIN
				set @step = @step + 1
				EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Full Backup User Databases', 
						@step_id=@step, 
						@cmdexec_success_code=0, 
						@on_success_action=3, 
						@on_success_step_id=0, 
						@on_fail_action=3, 
						@on_fail_step_id=0, 
						@retry_attempts=0, 
						@retry_interval=0, 
						@os_run_priority=0, @subsystem=N'TSQL', 
						@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''DatabaseBackup - USER_DATABASES - FULL''   ,@par_waitinterval = ''00:00:30''   ,@JobCompletionStatus = NULL', 
						@database_name=N'FDDBA', 
						@flags=0
				IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2
			END
		END

		set @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Run Daily Job', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''FD - Maintenance-Daily''   ,@par_waitinterval = ''00:00:30''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2


		set @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'integrity Check - USER_DATABASES', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''DatabaseintegrityCheck - USER_DATABASES''   ,@par_waitinterval = ''00:00:30''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2
	

		set @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'CommandLog Cleanup', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''CommandLog Cleanup''   ,@par_waitinterval = ''00:00:10''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2


		set @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Output File Cleanup', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''Output File Cleanup''   ,@par_waitinterval = ''00:00:10''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2



		set @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'sp_delete_backuphistory', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''sp_delete_backuphistory''   ,@par_waitinterval = ''00:00:10''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2

	
		set @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'sp_purge_jobhistory', 
				@step_id=@step, 
				@cmdexec_success_code=0, 
				@on_success_action=3, 
				@on_success_step_id=0, 
				@on_fail_action=3, 
				@on_fail_step_id=0, 
				@retry_attempts=0, 
				@retry_interval=0, 
				@os_run_priority=0, @subsystem=N'TSQL', 
				@command=N'EXECUTE dbo.pStartJobAndWait @par_JobName = N''sp_purge_jobhistory''   ,@par_waitinterval = ''00:00:10''   ,@JobCompletionStatus = NULL', 
				@database_name=N'FDDBA', 
				@flags=0
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2


		set @step = @step + 1
		EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobid, @step_name=N'Check for failures', 
			@step_id=@step, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, @subsystem=N'TSQL', 
			@command=N'DECLARE @jobid		uniqueidentifier
	DECLARE @rundate	int
	DECLARE @runtime	int
	DECLARE @startdt		DATETIME
	DECLARE @msg		VARCHAR(2048)
	--GET THE JOB ID
	SELECT @jobid =  CONVERT(uniqueidentifier,$(ESCAPE_NONE(JOBID)))
	PRint ''Job Id is: '' + ISNULL(CAST(@jobid as varchar(50)), ''nuLL'')
	--GET THE LATEST RUNTIME INFORMATION FROM ACTIVITY
	select 
		 @startdt = a.start_execution_date
		,@rundate =  CAST(convert(CHAR(8), a.start_execution_date,112) AS int)
		,@runtime =  CAST(REPLACE(convert(char(8), a.start_execution_date,108),'':'','''') AS int)
	 from
		sysjobactivity a
	Where
		a.job_id = @jobid
	--CHECK FOR ERRORS AND IF ANY OCCURRED RAISE AN ERROR TO FAIL THIS STEP
	IF EXISTS(
		SELECT 
			1
		 FROM
			sysjobhistory h
		 WHERE
			h.job_id = @jobid
			AND dbo.agent_datetime(h.run_date, h.run_time) >= @startdt
			AND run_status = 0 --failed
		)
	BEGIN
		PRint ''Failure found, returning Error to job step''
		RAISERROR(''One or more job steps failed, please investigate'',11,1) WITH NOWAIT;
	END
	ELSE
		PRint ''No step failures found :)''', 
			@database_name=N'msdb', 
			@flags=0

		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2
	
	
		EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobid, @start_step_id = 1
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2
	
		EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobid, @name= @WeeklyJobScheduleName, 
				@enabled=1, 
				@freq_type=8, 
				@freq_interval= @WeeklyJobScheduleFreqinterval, 
				@freq_subday_type=1, 
				@freq_subday_interval=0, 
				@freq_relative_interval=0, 
				@freq_recurrence_factor=1, 
				@active_start_date= @intdate, 
				@active_end_date=99991231, 
				@active_start_time= @WeeklyMaintJobStartTime, 
				@active_end_time=235959
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2
		EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobid, @server_name = N'(local)'
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback2
		COMMIT TRANSACTION
		GOTO EndSave2
		QuitWithRollback2:
			IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
		EndSave2:
		RAISERROR('Job "FD - Maintenance-Weekly" has been created and scheduled by this script.',10,1) WITH NOWAIT;
	END
	ELSE
		RAISERROR('Job "FD - Maintenance-Weekly" already exits and will not be created by this script.',10,1) WITH NOWAIT;
END
ELSE 
	RAISERROR('Parameter @WeeklyMaintJobStartTime is null so not creating Job "FD - Maintenance-Weekly".',10,1) WITH NOWAIT;

/************************************************************************************
		Set up job failure notifications
************************************************************************************/
RAISERROR('',10,1) WITH NOWAIT;
IF @NotificationOperator IS NOT NULL
BEGIN
	DECLARE curJobs	CURSOR  FAST_FORWARD LOCAL FOR
	SELECT jobname FROM #joblist 
	OPEN curJobs
	FETCH NEXT FROM curJobs intO @jobname
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @jobname AND notify_email_operator_id > 0)
		BEGIN
			SET @sql = N'EXEC msdb.dbo.sp_update_job @job_name=N'''  + @jobname  +''', 
			@notify_level_email=2, 
			@notify_level_netsend=2, 
			@notify_level_page=2, 
			@notify_email_operator_name=N''' +  @NotificationOperator   + ''''
			SET @msg = 'Adding operator ' + @NotificationOperator + ' to email notification for failure of job ''' + @jobname + '''.'
			RAISERROR(@msg,10,1) WITH NOWAIT;
			execute sp_executesql @stmt = @sql 
		END
		FETCH NEXT FROM curJobs intO  @jobname
	END
	CLOSE curJobs
	DEALLOCATE curJobs
END
ELSE
	RAISERROR('Parameter @NotificationOperator is NULL so script cannot add email notification on job failure.',10,1) WITH NOWAIT;





	
/************************************************************************************
						LAST STEP - DISABLE ALL JOBS IF REQUIRED
************************************************************************************/

RAISERROR('',10,1) WITH NOWAIT;
IF @DisableAllJobs = 1
BEGIN
	RAISERROR('About to disable all jobs.',10,1) WITH NOWAIT;
	SET @sql = '	EXECUTE msdb.dbo.sp_update_job @job_name=N''FD - Maintenance-Weekly'', @enabled = 0;
	EXECUTE msdb.dbo.sp_update_job @job_name=N''FD - Maintenance-Daily'', @enabled = 0;'
	RAISERROR('Disabling Daily and Weekly Maintenance jobs.',10,1) WITH NOWAIT;
	EXECUTE sp_executesql @stmt = @sql 
	
	DECLARE curJobs2	CURSOR  FAST_FORWARD LOCAL FOR
	SELECT jobname FROM #joblist 
	OPEN curJobs2
	FETCH NEXT FROM curJobs2 intO @jobname
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @sql = N'EXEC msdb.dbo.sp_update_job @job_name=N'''  + @jobname  +''', @enabled = 0'
		SET @msg = 'Disabling job ' + @jobname + '.'
		RAISERROR(@msg,10,1) WITH NOWAIT;
		execute sp_executesql @stmt = @sql 

		FETCH NEXT FROM curJobs2 intO  @jobname
	END
	CLOSE curJobs2
	DEALLOCATE curJobs2
END




/****************************************************************************************************
											VIEWS
****************************************************************************************************/
EXECUTE		sp_executesql N'use FDDBA'

SET ANSI_NULLS ON
--GO

SET QUOTED_IDENTIFIER ON
--GO
RAISERROR ('	CREATING OR ALTERING VIEW  dbo.vCommandLog_AlterIndex',10,1) WITH NOWAIT;
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vCommandLog_AlterIndex]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[vCommandLog_AlterIndex]
AS
SELECT 
	getdate() as [now]
  FROM
	dbo.CommandLog
' 
EXECUTE		sp_executesql N'
ALTER  VIEW [dbo].[vCommandLog_AlterIndex]
AS
SELECT 
	[ID]
	,DATEDIFF(SECOND,[StartTime],[EndTime]) AS Runtime_Sec
	,CONVERT(VARCHAR,DATEADD(SECOND,DATEDIFF(SECOND,StartTime,EndTime),0),108) AS RunTime
	,[DatabaseName]
	,[SchemaName]
	,[ObjectName]
	,[ObjectType]
	,[IndexName]
	,[IndexType]
	,[StatisticsName]
	,[PartitionNumber]
	,ExtendedInfo.value(''ExtendedInfo[1]/PageCount[1]'',''varchar(30)'') as PageCount
	,ExtendedInfo.value(''ExtendedInfo[1]/Fragmentation[1]'',''varchar(30)'') as Fragmentation
	,[ExtendedInfo]
	,[Command]
	,[CommandType]
	,[StartTime]
	,[EndTime]
	,[ErrorNumber]
	,[ErrorMessage]
 FROM 
	[dbo].[CommandLog]
WHERE
	CommandType = ''ALTER_INDEX'''


  

RAISERROR ('	CREATING OR ALTERING VIEW  dbo.vCommandLog_Backup',10,1) WITH NOWAIT;
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vCommandLog_Backup]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[vCommandLog_Backup]
AS
SELECT 
	getdate() as [now]
  FROM
	dbo.CommandLog
' 

EXECUTE		sp_executesql N'
ALTER  VIEW [dbo].vCommandLog_Backup
AS
SELECT 
	[ID]
	,DATEDIFF(SECOND,[StartTime],[EndTime]) AS Runtime_Sec
	,CONVERT(VARCHAR,DATEADD(SECOND,DATEDIFF(SECOND,StartTime,EndTime),0),108) AS RunTime
	,[DatabaseName]
	,[SchemaName]
	,[ObjectName]
	,[ObjectType]
	,[IndexName]
	,[IndexType]
	,[StatisticsName]
	,[PartitionNumber]
	,[ExtendedInfo]
	,[Command]
	,[CommandType]
	,[StartTime]
	,[EndTime]
	,[ErrorNumber]
	,[ErrorMessage]
 FROM 
	[dbo].[CommandLog]
WHERE
	CommandType IN(N''BACKUP_DATABASE'',N''BACKUP_LOG'')'



RAISERROR ('	CREATING OR ALTERING VIEW  dbo.vCommandLog_Checkdb',10,1) WITH NOWAIT;
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vCommandLog_Checkdb]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[vCommandLog_Checkdb]
AS
SELECT 
	getdate() as [now]
  FROM
	dbo.CommandLog
' 

EXECUTE		sp_executesql N'
ALTER  VIEW [dbo].vCommandLog_Checkdb
AS
SELECT 
	[ID]
	,DATEDIFF(SECOND,[StartTime],[EndTime]) AS Runtime_Sec
	,CONVERT(VARCHAR,DATEADD(SECOND,DATEDIFF(SECOND,StartTime,EndTime),0),108) AS RunTime
	,[DatabaseName]
	,[SchemaName]
	,[ObjectName]
	,[ObjectType]
	,[IndexName]
	,[IndexType]
	,[StatisticsName]
	,[PartitionNumber]
	,[ExtendedInfo]
	,[Command]
	,[CommandType]
	,[StartTime]
	,[EndTime]
	,[ErrorNumber]
	,[ErrorMessage]
 FROM 
	[dbo].[CommandLog]
WHERE
	CommandType = ''DBCC_CHECKDB'''



RAISERROR ('	CREATING OR ALTERING VIEW  dbo.vCommandLog_Statisics',10,1) WITH NOWAIT;
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vCommandLog_Statisics]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[vCommandLog_Statisics]
AS
SELECT 
	getdate() as [now]
  FROM
	dbo.CommandLog
' ;

EXECUTE		sp_executesql N'
ALTER  VIEW [dbo].vCommandLog_Statisics
AS
SELECT 
	[ID]
	,DATEDIFF(SECOND,[StartTime],[EndTime]) AS Runtime_Sec
	,CONVERT(VARCHAR,DATEADD(SECOND,DATEDIFF(SECOND,StartTime,EndTime),0),108) AS RunTime
	,[DatabaseName]
	,[SchemaName]
	,[ObjectName]
	,[ObjectType]
	,[IndexName]
	,[IndexType]
	,[StatisticsName]
	,[PartitionNumber]
	,ExtendedInfo.value(''ExtendedInfo[1]/RowCount[1]'',''bigint'') as [RowCountI]
	,ExtendedInfo.value(''ExtendedInfo[1]/ModificationCounter[1]'',''bigint'') as ModificationCounterI
	,CASE WHEN ExtendedInfo.value(''ExtendedInfo[1]/RowCount[1]'',''bigint'') >0 then
				CAST(((ExtendedInfo.value(''ExtendedInfo[1]/ModificationCounter[1]'',''decimal(28,2)'') /ExtendedInfo.value(''ExtendedInfo[1]/RowCount[1]'',''decimal(28,2)'') ) * 100) as decimal(28,2))
			else 0 end as ModPercent
	,ExtendedInfo
	,[Command]
	,[CommandType]
	,[StartTime]
	,[EndTime]
	,[ErrorNumber]
	,[ErrorMessage]
 FROM 
	[dbo].[CommandLog]
WHERE
	CommandType = ''UPDATE_STATISTICS''';







/**********************************************************************
Copied the below file code into this script to add the check for failure step
File: IndexOptimize Add Check for Failure Step.sql
Author: Keith Buck
Created: 11/6/2018

Purpose: This script is used to add a second step to the index maintenance
SQL Agent job to check for failures. On newer versions of SQL (2014+) we
have the WAIT_AT_LOW_PRIORITY option for online index rebuilds
https://docs.microsoft.com/en-us/sql/t-sql/statements/alter-index-transact-sql?view=sql-server-2017

If this option causes the command to fail and move on to the next one we
usually don't want to return a job failure as it worked as intended. To
avoid the failure run this code to add a second step that reviews all
Index and Statistics updates that were done by step 1 to see if there
were real errors and accordingly returns failure or success.

This script assumes the job only has one step and all works is
logged. If the commands are not logged then this will not work.
**********************************************************************/

--use msdb
--go
--ONLY RUN THIS IF WE HAVE SET THE @IndexMaintWaitAtLowPriortyTime parameter too
IF ISNULL(@IndexMaintWaitAtLowPriortyTime,0) > 0
BEGIN
	IF EXISTS(SELECT * from msdb.dbo.sysjobs j INNER JOIN msdb.dbo.sysjobsteps s on j.job_id = s.job_id WHERE j.name LIKE 'IndexOptimize%' AND s.step_id != 1 and s.step_name = N'Check for Failure') 
	BEGIN
		RETURN;
		RAISERROR('IndexOptimize [Check for Failure] step exists, will not add step.',15,1) WITH NOWAIT;

	END

	DECLARE @maxStep			int
	DECLARE @LastStep			int
	DECLARE @outputfile			NVARCHAR(200)

	SET @ReturnCode			= 0
	SET @jobId				= NULL

	SELECT TOP 1 @jobId = job_id FROM msdb.dbo.sysjobs WHERE (name LIKE N'IndexOptimize%')
	SELECT TOP 1 @maxStep = MAX(step_id) FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId
	SET @LastStep =  @maxStep + 1
	SELECT @outputfile = output_file_name FROM msdb.dbo.sysjobsteps WHERE job_id = @jobId AND step_id = 1


	--SELECT @jobId [jobid], @maxStep [MaxStep], @LastStep [LastStep], @outputfile [OutPutFile]
	IF @jobId IS NULL OR @maxStep IS NULL OR @outputfile IS NULL
	BEGIN
		RAISERROR('Null value, please fix before continuing.',15,1) WITH NOWAIT;
		RETURN;
	END



	---ADD THE SECOND STEP
	EXEC  msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check for Failure', 
			@step_id=@LastStep, 
			@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=2, 
			@on_fail_step_id=0, 
			@retry_attempts=0, 
			@retry_interval=0, 
			@os_run_priority=0, @subsystem=N'TSQL', 
			@command=N'SET NOCOUNT ON
	IF NOT EXISTS(SELECT * from msdb.dbo.sysjobs j INNER JOIN msdb.dbo.sysjobsteps s on j.job_id = s.job_id WHERE j.job_id = CONVERT(uniqueidentifier, $(ESCAPE_NONE(JOBID))) AND s.step_id = 1 AND s.command like ''%@WaitAtLowPriorityMaxDuration%'') 
	BEGIN
		PRint ''@WaitAtLowPriorityMaxDuration IS NOT SET FOR THIS JOB, SKIPPING CHECK AND RETURNING FAILURE''
		RAISERROR(''Error(s) occurred in Index Maintenance job, please reveiw'',15,1) WITH NOWAIT;
		RETURN
	END

	DECLARE @jobid							UNIQUEIDENTIFIER
	DECLARE @rundate						int
	DECLARE @runtime						int
	DECLARE @startdt						DATETIME
	DECLARE @msg							VARCHAR(2048)
	DECLARE @WaitAtLowPriorityMaxDuration	int = 10

	DECLARE @id				int
	DECLARE @command		NVARCHAR(MAX)
	DECLARE @errmsg			NVARCHAR(MAX)
	DECLARE @commandtype	NVARCHAR(60)
	DECLARE @start			DATETIME
	DECLARE @end			DATETIME
	DECLARE @haserror		bit = 0

	--GET THE JOB ID
	SELECT @jobid =  CONVERT(uniqueidentifier,$(ESCAPE_NONE(JOBID)))
	SET @msg = ''Job Id is: '' + ISNULL(CAST(@jobid as varchar(50)), ''nuLL'')
	RAISERROR(@msg,10,1) WITH NOWAIT;

	--try to read the value of @WaitAtLowPriorityMaxDuration from the job step
	DECLARE @tmp			VARCHAR(1000)
	DECLARE @tmp2			VARCHAR(1000)
	DECLARE @startLoc		int
	DECLARE @commaLoc		int			
	SELECT @tmp = s.command FROM msdb.dbo.sysjobsteps s WHERE s.job_id = @jobid AND  s.step_id = 1
	SET @startLoc = CHARINDEX(''@WaitAtLowPriorityMaxDuration'',@tmp,1) + LEN(''@WaitAtLowPriorityMaxDuration'')
	SET @commaLoc = CHARINDEX('','',@tmp,@startLoc)
	SET @tmp2 = LTRIM(RTRIM(REPLACE(SUBSTRING(@tmp, @startLoc, @commaLoc-@startLoc),''='','''')))


	IF ISNUMERIC(@tmp2) = 1
	BEGIN
		SET @WaitAtLowPriorityMaxDuration = CAST(@tmp2 AS int)
		PRint ''@WaitAtLowPriorityMaxDuration has been set to '' + @tmp2
	END	
	ELSE
		PRint ''Unable to determine WaitAtLowPriorityMaxDuration value in command, running with the default value of'' + CAST(@WaitAtLowPriorityMaxDuration AS VARCHAR(20))

	PRint ''''

	--GET THE LATEST RUNTIME INFORMATION FROM ACTIVITY
	SELECT 
			@startdt = a.start_execution_date
		FROM
		msdb.dbo.sysjobactivity a
	WHERE
		a.job_id = @jobid

	IF @startdt IS NULL
	BEGIN
		RAISERROR(''Unable to get job start date'', 15,1);
		RETURN;
	END

	DECLARE curJob CURSOR FAST_FORWARD FOR 
	SELECT 
		ID
		,Command
		,ErrorMessage
		,CommandType
		,StartTime
		,EndTime
		FROM
		FDDBA.dbo.CommandLog 
	WHERE
		StartTime >= @startdt
		AND CommandType IN (''ALTER_INDEX'',N''UPDATE_STATISTICS'')
		AND ErrorMessage IS NOT NULL
	
	OPEN curJob
	FETCH NEXT FROM curJob intO  @id, @command, @errmsg, @commandtype, @start, @end
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF  (@errmsg LIKE N''%Lock request time out period exceeded%'' 
			AND @commandtype = N''ALTER_INDEX''
			AND DATEDIFF(MINUTE, @start, @end) = @WaitAtLowPriorityMaxDuration)
		BEGIN--pretty much do nothing
			SET @msg = ''Wait at low priority error found for CommandLog.ID = '' + CAST(@id AS VARCHAR(20)) +''.''
			RAISERROR(@msg, 10,1) WITH NOWAIT;
		END
		ELSE IF @errmsg LIKE ''%was deadlocked on lock %''
		BEGIN
			SET @msg = ''Deadlock and we were chosen victim, this is okay.''
			RAISERROR(@msg, 10,1) WITH NOWAIT;
		END
		ELSE 
		BEGIN
			SET @haserror = 1
			PRint  ''Command type: '' + @commandtype
			PRint ''Error Message: '' + @errmsg
			PRint  ''DateDiff is: '' + CAST(DATEDIFF(MINUTE, @start, @end) AS VARCHAR(30))
			PRint  ''''
			BREAK
		END


		FETCH NEXT FROM curJob intO  @id, @command, @errmsg, @commandtype, @start, @end
	END
	CLOSE curJob
	DEALLOCATE curJob

	IF @haserror = 1
	BEGIN
		RAISERROR(''Error(s) occurred in Index Maintenance job, please reveiw'',15,1) WITH NOWAIT;
	END
	ELSE
		RAISERROR(''No errors found'', 10,1) WITH NOWAIT;
	', 
			@database_name=N'FDDBA', 
			@output_file_name= @outputfile, 
			@flags=0


	--UPDATE THE PREVIOUS LAST STEP
	EXEC  msdb.dbo.sp_update_jobstep 
			@job_id=@jobId
			,@step_id = @maxStep
			,@cmdexec_success_code=0, 
			@on_success_action=1, 
			@on_success_step_id=0, 
			@on_fail_action=3, 
			@on_fail_step_id=0
END
GO
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

