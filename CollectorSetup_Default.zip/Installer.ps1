$RegistryBase = 'HKLM:\SOFTWARE'
$RegistryKey = 'FortifiedData'
$BasePath = (Split-Path -parent $MyInvocation.MyCommand.Definition)
$ConfigFile = "$BasePath\Config.json"
$Config = (Get-Content $ConfigFile | Out-String | ConvertFrom-Json)
$ZipExePath = "$BasePath\sfk.exe"
Function Check-UserPrivilege
{
	Param (
		[String]$AccountName,
		[String]$PrivilegeName
		)
	$HasAccess = $False
	$ComputerName = $Env:Computername
	$DomainName = $AccountName.Substring(0, $AccountName.IndexOf('\'))
	If ($ComputerName -eq $DomainName) {
		$DomainName = ""
	}
	$CleanAccountName = $AccountName.Substring($AccountName.IndexOf('\') + 1)
	
	$ClassPath = "$BasePath\advapi.cs"
	Add-Type (Get-Content $ClassPath | Out-String)
	$LSA = New-Object PS_LSA.LsaWrapper($ComputerName)
	$Accounts = $LSA.EnumerateAccountsWithUserRight($PrivilegeName)
	
	If ($Accounts -Like "*$AccountName") {
		$HasAccess = $True
	}
	Else {
		Foreach ($CheckAccount in ($Accounts | Where-Object { $_.StartsWith('BUILTIN\') })) {
			$ADSIQuery = [adsi]"WinNT://$ComputerName/$($CheckAccount.Replace('BUILTIN\', '')),group"
			$QueryResults = $ADSIQuery.PSBase.Invoke("Members") | Select-Object @{Name="Name"; Expression={$_.GetType().InvokeMember("AdsPath", "GetProperty", $null, $_, $null).replace("WinNT://", "").replace("/","\")}}
			If ($QueryResults | Where-Object { $_.Name -Like "*$AccountName" }) {
				$HasAccess = $True
				Break
			}
		}
		If (!$HasAccess `
				-And !($AccountName -Like "$ComputerName*")) {
			Foreach ($CheckAccount in ($Accounts | Where-Object { $_.StartsWith("$DomainName\") })) {
				$Result = $Null
				Try {
					$Result = "net group $CheckAccount /domain 2>&1" | Where-Object { $_.Contains($CleanAccountName) }
				}
				Catch { }
				If ($Result) {
					$HasAccess = $True
					Break
				}
			}
		}
	}
	Return $HasAccess
}
Function Validate-Credentials
{

	Param(
		[String]$UserName,
		[Ref]$IsCredentialsOK
	)
	$IsCredentialsOK.Value = $False
	If ($Cred.UserName -eq "system") {
		$IsCredentialsOK.Value = $True
	}
	ElseIf ($Cred.UserName -Like '*\*') {
		If (Check-UserPrivilege -AccountName $Cred.UserName -PrivilegeName SeBatchLogonRight) {
			$IsCredentialsOK.Value = $True
		}
		Else {
			Write-Host -Object "The account does not have the ""Log on as a batch job"" privilege and cannot be used to run scheduled tasks." -ForegroundColor "Red"
		}
	}
	Else {
		Write-Host -Object "The account must be in the format of DomainName\AccountName or ComputerName\AccountName." -ForegroundColor "Red"
	}
}
Function Create-ScheduledTask
{
	Param(
		[String]$TaskName,
		[String]$Description,
		[String]$Command,
		[String]$Arguments,
		[PSCredential]$Cred,
		[String]$ScheduleType,
		[String]$Hour = ""
	)
	Get-ScheduledTask | Where-Object {$_.TaskName -like $TaskName} | Unregister-ScheduledTask -Confirm:$false
	Get-ScheduledTask | Where-Object {$_.TaskName -like $TaskName} | Unregister-ScheduledTask -Confirm:$false
	$RepetitionDuration = (New-TimeSpan -Days (365 * 20))
	If (!($ScheduleType -eq "Monthly")) {
		$STAction = New-ScheduledTaskAction -Execute $Command -Argument $Arguments
		Switch($ScheduleType) {
			("Minute") {$STTrigger = New-ScheduledTaskTrigger -Once -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration $RepetitionDuration -At $Hour}
			("Hourly") {$STTrigger = New-ScheduledTaskTrigger -Once -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration $RepetitionDuration -At $Hour}
			("Daily") {$STTrigger = New-ScheduledTaskTrigger -Daily -At $Hour}
			("StartUp") {$STTrigger = New-ScheduledTaskTrigger -AtStartup}
		}
		Try {
			If ($Cred.Username -eq "system")
			{
				Register-ScheduledTask -Action $STAction -Trigger $STTrigger -TaskName $TaskName -Description $Description -User "NT AUTHORITY\NETWORKSERVICE" -RunLevel Highest | Out-Null
			}
			Else
			{
				Register-ScheduledTask -Action $STAction -Trigger $STTrigger -TaskName $TaskName -Description $Description -User $Cred.Username `
										-Password $Cred.GetNetworkCredential().Password -RunLevel Highest | Out-Null
			}
		}
		Catch {
			Write-Host -Object "Unable to create $Description scheduled task - $($PSItem.ToString())."
		}
	}
	Else {
		$Command = "schtasks.exe /Create /TN $TaskName /SC monthly, /D 2, /ST $Hour /TR ""$Command $Arguments"" /RU $($Cred.Username) /RP $($Cred.GetNetworkCredential().Password) /RL HIGHEST"
		$Results = (Invoke-Expression -Command $Command)
		If (!($Results.Contains("SUCCESS"))) {
			Write-Host -Object "Unable to create $Description scheduled task - $Results."
		}
	}
}
Function Remove-ScheduledTask
{
	Param(
		[String]$TaskName
	)
	Get-ScheduledTask | Where-Object {$_.TaskName -like $TaskName} | Unregister-ScheduledTask -Confirm:$false
}
Function Get-UserOption
{
	Param (
		[Object]$Options,
		[Ref]$SelectedOption
	)
	$SelectedOption.Value = 0
	While ( $SelectedOption.Value -eq 0 ) {
		Clear-Host
		If ($PSVersion -lt [Float]5.1) {
			Write-Host -Object ""
			Write-Host -Object "PowerShell version $PSVersion is too low to support the Client Management components. Consider upgrading." -ForegroundColor "Red"
			Write-Host -Object ""
		}
		For ($i=1; $i -le $Options.Length; $i++) {
			Write-Host -Object "$i - $($Options[$i - 1])"
		}
		Write-Host -Object "IMPORTANT: Please don't forget to delete all of the files in the installer's folder when you're done." -ForegroundColor "Red"
		
		Write-Host -Object "Please type your selection followed by an <Enter>:"
		$Choice = (Read-Host)
		If ($Choice -eq "X") {
			$SelectedOption.Value = "Exit (X)"
		}
		ElseIf ($Options[[int]($Choice) - 1] -And [int]($Choice) -gt 0) {
			$SelectedOption.Value = $Options[[int]($Choice) - 1]
		}
	}
}
Function Test-AzureConnectivity
{
	Param (
		[Ref]$IsSuccessful
	)
	$IsSuccessful.Value = $false
	Try {
		If (!(Get-Module -ListAvailable -Name Az.Storage)) {
			Write-Host -Object "Installing Azure modules..."
			Install-Module Az -Force
		}
		Write-Host -Object "Testing connection to Azure..."
		$Context = (New-AzStorageContext -StorageAccountName $Config.CloudStorage.Account -StorageAccountKey $Config.CloudStorage.Key)
		If ($Context) {
			$IsSuccessful.Value = $true
		}
	}
	Catch {
		Throw $PSItem.ToString()
	}
}
Function Select-Folder
{
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

    $Dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $Dialog.Description = "Select a folder"
	$Dialog.ShowNewFolderButton = $false;
    $Dialog.RootFolder = "MyComputer"

    if($Dialog.ShowDialog() -eq "OK")
    {
        $SelectedFolder = $Dialog.SelectedPath
		return $SelectedFolder
    }
}
Function Get-InstallationPath
{
	Param(
		[Bool]$ConfigureIfDoesntExist = $true
	)
	Try {
		If (Test-Path -Path "$RegistryBase\$RegistryKey") {
			$InstallationPath = (Get-Item -Path "$RegistryBase\$RegistryKey").GetValue("ClientSideBasePath")
		}
	}
	Catch {}
	If (!$InstallationPath -And $ConfigureIfDoesntExist) {
		$InstallationPath = (Select-Folder)
		If ($InstallationPath) {
			New-Item -Path $RegistryBase -Name $RegistryKey -Force | Out-Null
			New-ItemProperty -Path "$RegistryBase\$RegistryKey" -Name ClientSideBasePath -Value $InstallationPath -Force | Out-Null
		}
	}
	If ($InstallationPath) {
		$Config.LocalPaths.ResultFiles = "$InstallationPath\CollectorResults"
		$Config.LocalPaths.Alerts = "$InstallationPath\Alerts"
		$Config.LocalPaths.ZipFiles = "$InstallationPath\UploadReady"
		$Config | ConvertTo-Json | Out-File -Encoding ascii -LiteralPath $ConfigFile
		$Config | ConvertTo-Json | Out-File -Encoding ascii -LiteralPath "$InstallationPath\ClientManagement\Config.json"
	}
	Return $InstallationPath
}
Function Install-Collector
{
	Param (
		[Ref]$IsSuccessful
	)
	$IsSuccessful.Value = $false
	$InstallationPath = (Get-InstallationPath)
	If ($InstallationPath) {
		Write-Host -Object "Installing Collector..."
		Invoke-Expression -Command "$ZipExePath unzip ""$BasePath\Collector.arc"" -todir $InstallationPath -yes -force"
		If (!(Test-Path -Path "$InstallationPath\Collector\ServerConfig.dat") -And !(Test-Path -Path "$InstallationPath\Collector\AppConfig.dat")) {
			Invoke-Expression -Command "$ZipExePath unzip ""$BasePath\CollectorLocalConfig.arc"" -todir $InstallationPath -yes -force"
		}

		Write-Host -Object "Installing Client Management Components..."
		Invoke-Expression -Command "$ZipExePath unzip ""$BasePath\ClientManagement.arc"" -todir $InstallationPath -yes -force"
		Write-Host -Object "Writing config file..."
		$ConfigFile = "$InstallationPath\ClientManagement\Config.json"

		$IsSuccessful.Value = $true
	}
}
Function Create-ClientManagementComponentsScheduledTasks
{
	Param (
		[Ref]$IsSuccessful
	)
	[Bool]$CanConnectToAzure = $false
	$IsSuccessful.Value = $false
	$InstallationPath = (Get-InstallationPath)
	If ($InstallationPath) {
		Test-AzureConnectivity -IsSuccessful ([Ref]$CanConnectToAzure)
		If ($CanConnectToAzure) {
			$Cred = Get-Credential -Message "Please enter credentials to be used for scheduled tasks (Use system for username to run tasks as NT AUTHORITY\NETWORKSERVICE)" -Username "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
			If ($Cred) {
				$IsCredentialsOK = $False
				Validate-Credentials -UserName $Cred.UserName -IsCredentialsOK ([Ref]$IsCredentialsOK)
				If ($IsCredentialsOK) {
					$CertificateCredentials = (Get-Credential -Message "Please type the certificate decryption password" -Username "No User Name")
					If ($CertificateCredentials) {
						Try {
							Write-Host -Object "Importing certificate..."
							Import-PfxCertificate -FilePath "$BasePath\QueueMessageEncryption.pfx" -CertStoreLocation Cert:\LocalMachine\My -Password $CertificateCredentials.Password | Out-Null
							If ($Cred) {
								Write-Host -Object "Creating scheduled tasks..."
								Create-ScheduledTask -TaskName "FD_Uploader" -Description "Uploads FD Collector Result files to Azure Blob Storage" -Command "powershell.exe" `
														-Arguments "-NoProfile -ExecutionPolicy Bypass -File $InstallationPath\ClientManagement\Uploader.ps1" -ScheduleType "Minute" -Hour "12am" -Cred $Cred
								Create-ScheduledTask -TaskName "FD_ClientReceiver" -Description "Receives instructions from FD central server" -Command "powershell.exe" `
														-Arguments "-NoProfile -ExecutionPolicy Bypass -File $InstallationPath\ClientManagement\LoopLauncher.ps1 -LoopCommand ""& $InstallationPath\ClientManagement\ClientReceiver.ps1"" -IntervalSeconds 60" `
														-ScheduleType "Minute" -Hour "12am" -Cred $Cred
								Write-Host -Object "Client Management Components installed successfully."
								$IsSuccessful.Value = $true
							}
						}
						Catch {
							Throw $PSItem.ToString()
						}
					}
				}
			}
		}
	}
}
Function Remove-ClientManagementComponentsScheduledTasks
{
	$InstallationPath = (Get-InstallationPath)
	If ($InstallationPath) {
		Write-Host -Object "Uninstalling scheduled tasks..."
		Remove-ScheduledTask -TaskName "FD_Uploader"
		Remove-ScheduledTask -TaskName "FD_ClientReceiver"
	}
}
Function Create-CollectorScheduledTask
{
	Param (
		[Ref]$IsSuccessful
		)
	$IsSuccessful.Value = $false
	$InstallationPath = (Get-InstallationPath)
	If ($InstallationPath) {
		If (Test-Path -Path "$InstallationPath\Collector\FortifiedData.CollectorUI.exe") {
			$Cred = Get-Credential -Message "Please enter credentials to be used for scheduled tasks (Use system for username to run tasks as AUTHORITY\SYSTEM)" -Username "$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
			If ($Cred) {
				$IsCredentialsOK = $False
				Validate-Credentials -UserName $Cred.UserName -IsCredentialsOK ([Ref]$IsCredentialsOK)
				If ($IsCredentialsOK) {
					Write-Host -Object "Creating scheduled tasks..."
					Create-ScheduledTask -TaskName "FD_RunCollector" -Description "Runs the FD Collector" -Command "powershell.exe" `
											-Arguments "-NoProfile -ExecutionPolicy Bypass -File $InstallationPath\ClientManagement\LoopLauncher.ps1 -LoopCommand ""& $InstallationPath\ClientManagement\RunCollector.ps1"" -IntervalSeconds 60" -ScheduleType "Minute" -Hour "12am" -Cred $Cred
					Create-ScheduledTask -TaskName "FD_RunCollectorMonitoring" -Description "Runs the FD Collector Monitoring Module" -Command "powershell.exe" `
											-Arguments "-NoProfile -ExecutionPolicy Bypass -File $InstallationPath\ClientManagement\LoopLauncher.ps1 -LoopCommand ""& $InstallationPath\ClientManagement\RunCollectorMonitoring.ps1"" -IntervalSeconds 60" -ScheduleType "Minute" -Hour "12am" -Cred $Cred
					Create-ScheduledTask -TaskName "FD_Alerter" -Description "Runs the Alert Uploader" -Command "powershell.exe" `
											-Arguments "-NoProfile -ExecutionPolicy Bypass -File $InstallationPath\ClientManagement\LoopLauncher.ps1 -LoopCommand ""& $InstallationPath\ClientManagement\Alerter.ps1"" -IntervalSeconds 10" -ScheduleType "Minute" -Hour "12am" -Cred $Cred
					If (Get-ScheduledTask | Where-Object {$_.TaskName -eq "FD_RunCollector"}) {
						$IsSuccessful.Value = $true
						Start-ScheduledTask -TaskName "FD_RunCollector"
						Start-ScheduledTask -TaskName "FD_RunCollectorMonitoring"
						Start-ScheduledTask -TaskName "FD_Alerter"
					}
				}
			}
		}
	}
}
Function Remove-CollectorScheduledTasks
{
	$InstallationPath = (Get-InstallationPath)
	If ($InstallationPath) {
		Write-Host -Object "Uninstalling scheduled tasks..."
		Remove-ScheduledTask -TaskName "FD_RunCollector"
	}
}
Function ZipUp-Files
{
	Param(
		[String]$ZipExePath,
		[Int]$MinutesDelay,
		[String]$ResultFilesPath,
		[String]$ZipFilesPath,
		[Int]$ClientID
	)
	$DateToZip = (Get-Date).AddMinutes(-$MinutesDelay)
	$Files = (Get-ChildItem -Path "$ResultFilesPath\*.*"  -File | Where-Object { $_.LastWriteTime -lt $DateToZip }) | Select-Object -First 1
	If ($Files) {
		$ZipFileName = "$ZipFilesPath\$ClientID_$(Get-Date -Format "MM_dd_yyyy_HH_mm_ss").zip1"
		$Command = "$ZipExePath zip -before $($DateToZip.ToString("yyyyMMddHHmmss")) -rel ""$ZipFileName"" ""$($Config.LocalPaths.ResultFiles)"" -force -nosub -yes"
		Invoke-Expression $Command | Out-Null
		$Command = "$ZipExePath list -rel -arc ""$ZipFileName"""
		Invoke-Expression $Command | ForEach-Object {
			Remove-Item -Path "$ResultFilesPath\$($_)" -Force
		}
	}
}
Function Display-InstallationInfo
{
	$InstallationPath = (Get-InstallationPath -ConfigureIfDoesntExist $false)
	If ($InstallationPath) {
		Write-Host -Object "Installtion Info:" -ForegroundColor "Green"
		Write-Host -Object "	Installtion Path: $InstallationPath"
		Write-Host -Object "	Collector:" -NoNewline
		If (Test-Path -Path "$InstallationPath\Collector\*.*") {
			Write-Host -Object ""
			Write-Host -Object "		Path: $InstallationPath\Collector"
			$Versions = (Invoke-Expression -Command "$InstallationPath\Collector\FortifiedData.CollectorUI.exe --Operation:List --Subject:Versions")
			$Versions | Where-Object { !($_ -Like '[[]*') } | Foreach-Object {
				Write-Host -Object "	    $($_ -Replace ":", " Version:")"
			}
		}
		Else {
			Write-Host -Object " Not Installed"
		}
		Write-Host -Object "		Scheduled Tasks:" -NoNewline
		$ScheduledTasks = (Get-ScheduledTask | Where-Object {$_.TaskName -eq "FD_RunCollector"})
		If ($ScheduledTasks) {
			Write-Host -Object ""
			$ScheduledTasks | ForEach-Object {
				Write-Host -Object "			$($_.TaskName) - $($_.State)"
			}
		}
		Else {
			Write-Host -Object " None"
		}
		Write-Host -Object ""
		Write-Host -Object "	Client Management Components:" -NoNewline
		If (Test-Path -Path "$InstallationPath\ClientManagement\*.*") {
			Write-Host -Object ""
			Write-Host -Object "		Path: $InstallationPath\ClientManagement"
		}
		Else {
			Write-Host -Object " Not Installed"
		}		Write-Host -Object "		Scheduled Tasks:" -NoNewline
		$ScheduledTasks = (Get-ScheduledTask | Where-Object {$_.TaskName -eq "FD_Uploader" -Or $_.TaskName -eq "FD_ClientReceiver"})
		If ($ScheduledTasks) {
			Write-Host -Object ""
			$ScheduledTasks | ForEach-Object {
				Write-Host -Object "			$($_.TaskName) - $($_.State)"
			}
		}
		Else {
			Write-Host -Object " None"
		}
	}
	Else {
		Write-Host -Object "	No installation path found in Registry."
	}
}
[String]$SelectedOption = 0
[Bool]$IsSuccessful = $false
[Float]$PSVersion = "$($PSVersionTable.PSVersion.Major).$($PSVersionTable.PSVersion.Minor)"
$Options = @()

$Options += "Install\Update Collector"
$Options += "Create Client Management Scheduled Tasks"
$Options += "Run the Collector"
$Options += "Create the Collector's Scheduled Task"
$Options += "Start an Extensive Collection"
$Options += "Zip-Up Result Files"
$Options += "Check Azure Connectivity"
$Options += "Display Installation Info"
$Options += "Remove the Collector's Scheduled Task"
$Options += "Remove the Client Management Components Scheduled Tasks"
$Options += "Exit (X)"

While (1 -eq 1) {
	Get-UserOption -Option $Options -SelectedOption ([Ref]$SelectedOption)
	Clear-Host
	Switch($SelectedOption) {
		"Install\Update Collector" {
			Install-Collector -IsSuccessful ([Ref]$IsSuccessful)
			If ($IsSuccessful) {
				Write-Host -Object "Done!" -ForegroundColor "Green"
			}
			Else {
				Write-Host -Object "Installation cancelled." -ForegroundColor "Red"
			}
		}
		"Create Client Management Scheduled Tasks" {
			If ($PSVersion -ge [Float]5.1) {
				Create-ClientManagementComponentsScheduledTasks -IsSuccessful ([Ref]$IsSuccessful)
				If ($IsSuccessful) {
					Write-Host -Object "Done!" -ForegroundColor "Green"
				}
				Else {
					Write-Host -Object "Installation cancelled." -ForegroundColor "Red"
				}
			}
			Else {
				Write-Host -Object "Options is not upported by the current version of PowerShell." -ForegroundColor "Red"
			}
		}
		"Run the Collector" {
			$InstallationPath = (Get-InstallationPath -ConfigureIfDoesntExist $false)
			If ($InstallationPath) {
				& $InstallationPath\Collector\FortifiedData.CollectorUI.exe
			}
			Else {
				Write-Host -Object "No installation path found in Registry." -ForegroundColor "Red"
			}
		}
		"Create the Collector's Scheduled Task" {
			Create-CollectorScheduledTask -IsSuccessful ([Ref]$IsSuccessful)
			If ($IsSuccessful) {
				Write-Host -Object "Done!" -ForegroundColor "Green"
			}
			Else {
				Write-Host -Object "Scheduled Tasks creation failed." -ForegroundColor "Red"
			}

		}
		"Start an Extensive Collection" {
			$InstallationPath = (Get-InstallationPath)
			$TaskName = "FD_RunCollector"
			If (Get-ScheduledTask | Where-Object {$_.TaskName -eq $TaskName}) {
				"" | Out-File -Encoding ascii -LiteralPath "$InstallationPath\ClientManagement\RunCollector_Basic.now"
				Write-Host -Object "A collection has been scheduled and will be executed soon." -ForegroundColor "Green"
			}
			Else {
				Write-Host -Object "Scheduled Tasks $TaskName counld not be found." -ForegroundColor "Red"
			}
		}
		"Zip-Up Result Files" {
			$InstallationPath = (Get-InstallationPath)
			If ($InstallationPath) {
				Write-Host -Object "Close all instances of the Collector and disable all Collector Scheduled Tasks, then press <Enter> to continue..."
				Read-Host | Out-Null
				If (!(Get-Process | Where-Object { $_.Name -Eq "FortifiedData.CollectorUI" })) {
					$Config = (Get-Content $ConfigFile | Out-String | ConvertFrom-Json)
					New-Item -ItemType Directory -Force -Path $Config.LocalPaths.ZipFiles | Out-Null
					ZipUp-Files -ZipExePath $ZipExePath -MinutesDelay 0 -ResultFilesPath $Config.LocalPaths.ResultFiles -ZipFilesPath $Config.LocalPaths.ZipFiles -ClientID $Config.Client.ID
					Write-Host -Object "Zip files are under $($Config.LocalPaths.ZipFiles)" -ForegroundColor "Green"
				}
				Else {
					Write-Host -Object "Can't Zip-Up Result Files while the Collector is running." -ForegroundColor "Red"
				}
				Write-Host -Object "Make sure to enable all Collector Scheduled Tasks!" -ForegroundColor "Red"
			}
			Else {
				Write-Host -Object "Zip-Up operation cancelled!" -ForegroundColor "Red"
			}
		}
		"Check Azure connectivity" {
			If ($PSVersion -ge [Float]5.1) {
				Test-AzureConnectivity -IsSuccessful ([Ref]$IsSuccessful)
				If ($IsSuccessful) {
					Write-Host -Object "Connected to Azure storage." -ForegroundColor "Green"
				}
				Else {
					Write-Host -Object "Connection to Azure storage failed." -ForegroundColor "Red"
				}
			}
			Else {
				Write-Host -Object "Options is not supported by the current version of PowerShell." -ForegroundColor "Red"
			}

		}
		"Display Installation Info" {
			Display-InstallationInfo
		}
		"Remove the Collector's Scheduled Task" {
			Remove-CollectorScheduledTasks
			Write-Host -Object "Done!" -ForegroundColor "Green"
		}
		"Remove the Client Management Components Scheduled Tasks" {
			Remove-ClientManagementComponentsScheduledTasks
			Write-Host -Object "Done!" -ForegroundColor "Green"
		}
		"Exit (X)" {
			Return
		}
	}
	Write-Host -Object "Press any key to continue..."
	$Host.UI.RawUI.ReadKey() | Out-Null
}